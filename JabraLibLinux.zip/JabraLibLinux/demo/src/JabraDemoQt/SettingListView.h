#ifndef SETTINGLISTVIEW_H
#define SETTINGLISTVIEW_H

#include <QLabel>
#include <QList>
#include "JabraDeviceConfig.h"
#include "SettingWidget.h"

/**
 * @brief The SettingListView class holds all settings for a device. A setting is
 * an instance of the SettingWidget class containing UI components for displaying
 * manipulating and validating an actual device setting. The SettingListView caches
 * the SettingWidgets, so if a setting is changed the cache must be invalidated.
 */
class SettingListView
{
  /** @brief List with widgets, one widget per setting. */
  QList<SettingWidget*> mSettingsList;

  /** @brief List with labels, one label per setting. */
  QList<QLabel*> mSettingsLabelList;

  /** @brief List of changed settings widgets, used for apply button. */
  QList<SettingWidget*> mSettingsChanged;

  /** @brief Status of the setting cache, valid or invalid. */
  bool mInvalidateCache;

public:
  /** @brief Constructor. */
  SettingListView() : mInvalidateCache(true) { }

  /** @brief Destructor. */
  ~SettingListView();

  /**
   * @brief Builds the list of setting widgets from the @arg settings structure
   * (from the device) and adds them to the parent layout.
   * @param[in] settings the settings structure containing the supported settings
   * of the device.
   * @param[in] parent parent widget (setting widget owner).
   */
  void BuildSettingList(DeviceSettings* settings, QWidget* parent = 0);

  /**
   * @brief Clears the list of settings and deletes the references.
   */
  void ClearAndDelete();

  /**
   * @brief Clear list of changed settings, used when settings have been applied
   * to the device successfully.
   */
  void ClearChanged();

  /**
   * @brief Get access to the list of supported settings.
   * @return list of setting that the device supports.
   */
  QList<SettingWidget*>& GetSettingsWidgets() { return mSettingsList; }

  /**
   * @brief Get access to the list of changed settings.
   * @return list of setting that has changed i.e. settings to be written to the device.
   */
  QList<SettingWidget*>& GetSettingsWidgetsChanged() { return mSettingsChanged; }

  /**
   * @brief Mark the setting as changed i.e. it is added to the list of changed settings.
   * @param[in] widget the setting that has changed.
   */
  void MarkSettingChanged(SettingWidget* widget);

  /**
   * @brief Has the setting cache been invalidated i.e. do we have to build a new list of
   * SettingWidgets.
   * @return true if the cache has been invalidated, false if not (no changes).
   */
  bool HasCacheBeenInvalidated() { return mInvalidateCache; }

  /**
   * @brief Used to invalidate the settings cache.
   */
  void InvalidateCache() { mInvalidateCache = true; }
};

#endif /* SETTINGLISTVIEW_H */
