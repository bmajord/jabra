#include <QMessageBox>
#include <QDebug>
#include <QMutex>
#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "JabraNativeHid.h"
#include "RemoteMmiListView.h"

const QString MainWindow::ReadAppIdFile(const QString &filename) {
  QFile f(filename);
  if(f.open(QFile::ReadOnly | QFile::Text)) {
    QTextStream in(&f);
    QString text = in.readLine();
    text = text.trimmed();
    f.close();
    return text;
  }
  return "";
}

MainWindow::MainWindow(QWidget *parnt) : QMainWindow(parnt), ui(new Ui::MainWindow), mRemoteMmiList(nullptr) {
  char buffer[512];

  /* Setup UI components (maintained by Qt) */
  ui->setupUi(this);

  /* Create icon preview area for displaying and selecting Jabra devices */
  mPreviewArea = new ThumbListView(ui->scrollAreaIconPreviewWidget);

  /* Read application ID from the app.id file */
  QString appId = ReadAppIdFile("app.id");

  /* Set application ID of this app */
  Jabra_SetAppID(const_cast<char*>(appId.toStdString().c_str()));

  /* Get and display SDK version */
  if(Return_Ok == Jabra_GetVersion(buffer, static_cast<int>(sizeof(buffer)))) {
    setWindowTitle(tr("SDK version ") + QString(buffer));
  } else {
    setWindowTitle(tr("SDK version can't be determined"));
  }

  /* Register types for use with signals/slots */
  qRegisterMetaType<Jabra_DeviceInfo>("Jabra_DeviceInfo");
  qRegisterMetaType<Jabra_HidInput>("Jabra_HidInput");
  qRegisterMetaType<Jdevice*>("Jdevice*");

  /* Connect signals and slots for Jabra_Initialize callbacks */
  connect(this, SIGNAL(signalOnJabraDeviceAdded(Jdevice*)), this, SLOT(OnJabraDeviceAdded(Jdevice*)));
  connect(this, SIGNAL(signalOnJabraDeviceRemoved(unsigned short)), this, SLOT(OnJabraDeviceRemoved(unsigned short)));
  connect(this, SIGNAL(signalOnJabraButtonInDataRawHidFunc(unsigned short, unsigned short, unsigned short, bool)), this, SLOT(OnJabraButtonInDataRawHidFunc(unsigned short, unsigned short, unsigned short, bool)));
  connect(this, SIGNAL(signalOnJabraButtonInDataTranslatedFunc(unsigned short, Jabra_HidInput, bool)), this, SLOT(OnJabraButtonInDataTranslatedFunc(unsigned short, Jabra_HidInput, bool)));

  /* Initialize Jabra library with callbacks for attach, remove and input events */
  if(!Jabra_Initialize(nullptr, JabraDeviceAttachedFunc, JabraDeviceRemovedFunc, JabraButtonInDataRawHidFunc, JabraButtonInDataTranslatedFunc, 0)) {
    showMessage(tr("Unable to initialize library, please check the application ID"), tr(""));
    return;
  }

  /* Connect signals and slots for Jabra_RegisterBusylightEvent and others */
  connect(this, SIGNAL(signalOnJabraBusylightFunc(unsigned short, bool)), this, SLOT(OnJabraBusylightFunc(unsigned short, bool)));
  connect(this, SIGNAL(signalOnJabraButtonGNPEventFunc(unsigned short, ButtonEvent*)), this, SLOT(OnJabraButtonGNPEventFunc(unsigned short, ButtonEvent*)));
  connect(this, SIGNAL(signalOnJabraPairingListFunc(unsigned short, Jabra_PairingList*)), this, SLOT(OnJabraPairingListFunc(unsigned short, Jabra_PairingList*)));

  /* Register callbacks */
  Jabra_RegisterBusylightEvent(JabraBusylightFunc);
  Jabra_RegisterForGNPButtonEvent(JabraButtonGNPEventFunc);
  Jabra_RegisterPairingListCallback(JabraPairingListFunc);

  /* Connect signal and slot for preview area widget */
  connect(mPreviewArea, SIGNAL(DeviceSelected(Jdevice*)), this, SLOT(onDeviceSelected(Jdevice*)));
  connect(mPreviewArea, SIGNAL(DeviceLocked(Jdevice*)), this, SLOT(onDeviceLocked(Jdevice*)));
}

MainWindow::~MainWindow() {
  if(Jabra_Uninitialize() == false) {
    qCritical() << "Unable to uninitialize";
  }
  delete mPreviewArea;
  delete ui;
}

/* Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraDeviceAttachedFunc(Jabra_DeviceInfo deviceInfo) {

  qDebug() << "Device attached:" << deviceInfo.deviceName << "with id" << deviceInfo.deviceID;
  Jdevice* newDevice = new Jdevice(deviceInfo.deviceID,
                                   deviceInfo.productID,
                                   QString(deviceInfo.deviceName),
                                   QString(deviceInfo.usbDevicePath),
                                   QString(deviceInfo.parentInstanceId),
                                   deviceInfo.isBTPaired,
                                   QString(deviceInfo.dongleName));

  /* Free (contents of) structure */
  Jabra_FreeDeviceInfo(deviceInfo);

  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraDeviceAdded(newDevice);
}

/* Jabra device added, called via static method */
void MainWindow::OnJabraDeviceAdded(Jdevice* device) {
  device->Init();
  mPreviewArea->AddDevice(device);

  /* A Bluetooth device connected via the dongle is already locked if dongle is locked prior to connection establishment */
  if(device->IsLocked()){
    /* Determine if this program instance locked this device */
    if(Return_Ok == device->Lock()) {
      device->InitializeCallControl();
      mPreviewArea->SetButtonText(device, tr("Locked"));
    }
  }
  UpdateUiComponents();
}

/* Common: Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraDeviceRemovedFunc(unsigned short deviceID) {
  qDebug() << "Device with id " << deviceID << "removed";
  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraDeviceRemoved(deviceID);
}

/* Common: Jabra device removed, called via static method */
void MainWindow::OnJabraDeviceRemoved(unsigned short deviceID) {
  Jdevice* device = mPreviewArea->GetSpecificDevice(deviceID);
  if(device) {
    mPreviewArea->RemoveDevice(deviceID);
    UpdateUiComponents();
  }
}

/* Common: Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraButtonInDataRawHidFunc(unsigned short deviceID, unsigned short usagePage, unsigned short usage, bool buttonInData) {
  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraButtonInDataRawHidFunc(deviceID, usagePage, usage, buttonInData);
}

/* Common: Handler for the raw HID inputs/events */
void MainWindow::OnJabraButtonInDataRawHidFunc(unsigned short deviceID, unsigned short usagePage, unsigned short usage, bool buttonInData) {
  QString line = QString("%1: 0x%2 0x%3 %4").arg(deviceID).arg(usagePage, 4, 16, QChar('0')).arg(usage, 4, 16, QChar('0')).arg(buttonInData);
  ui->listBoxCcRaw->insertItem(0, line);
}

/* Common: Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraButtonInDataTranslatedFunc(unsigned short deviceID, Jabra_HidInput translatedInData, bool buttonInData) {
  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraButtonInDataTranslatedFunc(deviceID, translatedInData, buttonInData);
}

/* Common: Handler for the translated HID inputs/events */
void MainWindow::OnJabraButtonInDataTranslatedFunc(unsigned short deviceID, Jabra_HidInput translatedInData, bool buttonInData) {
  Jdevice* device = mPreviewArea->GetSpecificDevice(deviceID);
  if(device == nullptr) {
    return;
  }

  QString translated;
  mMtx.lock();

  switch (translatedInData) {
    case Undefined:
      translated = tr("Undefined");
      break;
    case OffHook:
      translated = tr("Off Hook");
      /* Acknowledge by sending a off hook command with the received button value */
      if(Return_Ok == Jabra_SetOffHook(device->GetId(), buttonInData)) {
        device->GetState().OffHook = buttonInData;
      }
      break;
    case Mute:
      translated = tr("Mute");
      /* Acknowledge by sending a mute command with the received button value */
      if(Return_Ok == Jabra_SetMute(device->GetId(), buttonInData)) {
        device->GetState().Mute = buttonInData;
      }
      break;
    case Flash:
      translated = tr("Flash");
      if(device->GetState().Hold) {
        if(Return_Ok == Jabra_SetOffHook(device->GetId(), true)) {
          device->GetState().OffHook = true;
        }
        if(Return_Ok == Jabra_SetHold(device->GetId(), false)) {
          device->GetState().Hold = false;
        }
      }
      else {
        if(Return_Ok == Jabra_SetHold(device->GetId(), true)) {
          device->GetState().Hold = true;
        }
        if(Return_Ok == Jabra_SetOffHook(device->GetId(), false)) {
          device->GetState().OffHook = false;
        }
      }
      break;
    case Redial:
      translated = tr("Redial");
      break;
    case Key0:
      translated = tr("Key0");
      break;
    case Key1:
      translated = tr("Key1");
      break;
    case Key2:
      translated = tr("Key2");
      break;
    case Key3:
      translated = tr("Key3");
      break;
    case Key4:
      translated = tr("Key4");
      break;
    case Key5:
      translated = tr("Key5");
      break;
    case Key6:
      translated = tr("Key6");
      break;
    case Key7:
      translated = tr("Key7");
      break;
    case Key8:
      translated = tr("Key8");
      break;
    case Key9:
      translated = tr("Key9");
      break;
    case KeyStar:
      translated = tr("Key*");
      break;
    case KeyPound:
      translated = tr("Key#");
      break;
    case KeyClear:
      translated = tr("KeyClear");
      break;
    case Online:
      translated = tr("Online");
      break;
    case SpeedDial:
      translated = tr("SpeedDial");
      break;
    case VoiceMail:
      translated = tr("VoiceMail");
      break;
    case LineBusy:
      translated = tr("LineBusy");
      break;
    case RejectCall:
      translated = tr("RejectCall");
      break;
    case OutOfRange:
      translated = tr("OutOfRange");
      break;
    case PseudoOffHook:
      translated = tr("PseudoOffHook");
      break;
    case Button1:
      translated = tr("Button1");
      break;
    case Button2:
      translated = tr("Button2");
      break;
    case Button3:
      translated = tr("Button3");
      break;
    case VolumeUp:
      translated = tr("VolumeUp");
      break;
    case VolumeDown:
      translated = tr("VolumeDown");
      break;
    case FireAlarm:
      translated = tr("FireAlarm");
      break;
    case JackConnection:
      translated = tr("JackConnection");
      break;
    case QDConnection:
      translated = tr("QDConnection");
      break;
    case HeadsetConnection:
      translated = tr("HeadsetConnection");
      device->SetHeadsetConnected(buttonInData);
      if(device == mPreviewArea->GetSelectedDevice()) {
        UpdateUiComponentsBluetooth(device);
      }
      break;
    default:
      break;
  }

  ui->listBoxCcTranslated->insertItem(0, QString("%1: %2: %3").arg(deviceID).arg(translated).arg(buttonInData));

  if(device == mPreviewArea->GetSelectedDevice()) {
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Common: Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraBusylightFunc(unsigned short deviceID, bool busylightValue) {
  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraBusylightFunc(deviceID, busylightValue);
}

/* Common: Busy light event, called via static method */
void MainWindow::OnJabraBusylightFunc(unsigned short deviceID, bool busylightValue) {
  Jdevice* device = mPreviewArea->GetSpecificDevice(deviceID);
  if(device) {
    mMtx.lock();
    device->GetState().BusyLight = busylightValue;
    if(device == mPreviewArea->GetSelectedDevice()) {
      UpdateUiComponentsCallControl(device);
    }
    mMtx.unlock();
  }
}

/* Common: Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraButtonGNPEventFunc(unsigned short deviceID, ButtonEvent* buttonEvent) {
  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraButtonGNPEventFunc(deviceID, buttonEvent);
}

/* Common: GNP button event, called via static method */
void MainWindow::OnJabraButtonGNPEventFunc(unsigned short deviceID, ButtonEvent* buttonEvent) {
  Jdevice* device = mPreviewArea->GetSpecificDevice(deviceID);
  if(buttonEvent && device) {
    for(int i=0; i<buttonEvent->buttonEventCount; i++) {
      ButtonEventInfo* info = buttonEvent->buttonEventInfo;
      if(info) {
        QString line = QString("%1: BtnType=0x%2, BtnValue=%3, Events { %4 }");
        line = line.arg(deviceID);
        line = line.arg(info->buttonTypeKey, 4, 16, QChar('0'));
        line = line.arg(info->buttonTypeValue);
        for(int j=0; j<info->buttonEventTypeSize; j++) {
          ButtonEventType* eventType = info->buttonEventType + j;
          QString subline = QString("{%1 %2}");
          subline = subline.arg(eventType->key);
          subline = subline.arg(eventType->value);
          line = line.arg(subline);
          QString value;
          if(device->GetMmiInFocus(info->buttonTypeKey, eventType->key, value)) {
            line.append(", message {%1}");
            line = line.arg(value);
          }
        }
        ui->listBoxMmiEvents->insertItem(0, line);
      }
    }
  }
}

/* Common: Static method used for callback from Jabra library. Note: This callback is run in a worker thread, not the main thread */
void MainWindow::JabraPairingListFunc(unsigned short deviceID, Jabra_PairingList* lst) {
  /* Signal main thread */
  emit MainWindow::GetInstance().signalOnJabraPairingListFunc(deviceID, lst);
}

/* Common: Paired device event, called via static method */
void MainWindow::OnJabraPairingListFunc(unsigned short deviceID, Jabra_PairingList* lst) {
  qDebug() << __FUNCTION__ << " " << deviceID << " Jabra_PairingList.count:" << lst->count;
}

/* ------------------------------------------------------------------------- */
/* Product Information */
/* ------------------------------------------------------------------------- */

/* Product Information: Updates Product Information UI components */
void MainWindow::UpdateUiComponentsProductInfo(Jdevice* device) {
  const QString version = tr("Firmware version: ");
  const QString serial = tr("Serial number: ");
  QString v = "-";

  if(device) {
    /* Display name of selected device */
    ui->labelDeviceName->setText(device->GetName());

    /* Get product image and display it */
    ui->labelProductImage->setPixmap(device->GetImage());

    /* Get info about device */
    char buffer[80];
    if(Return_Ok == Jabra_GetFirmwareVersion(device->GetId(), buffer, (int)sizeof(buffer))) {
      v = buffer;
      if(device->IsHeadsetConnected()) {
        v.append(" (dongle)");
      }
    }
    ui->labelVersion->setText(version + v);

    Jabra_ReturnCode rc = Jabra_GetSerialNumber(device->GetId(), buffer, (int)sizeof(buffer));
    if(Return_Ok == rc) {
      v = buffer;
    }
    if(No_Information == rc) {
      v = tr("no serial number available");
    }
    if(NetworkRequest_Fail == rc) {
      v = tr("error getting serial number via network");
    }
    ui->labelSerial->setText(serial + v);

  } else {
    /* Display empty device name */
    ui->labelDeviceName->setText(tr("Device name: -"));

    /* Display empty device firmware version */
    ui->labelVersion->setText(tr("Firmware version: -"));

    /* Clear product image */
    ui->labelProductImage->clear();

    /* Display empty device serial number */
    ui->labelSerial->setText(tr("Serial number: -"));
  }
}

/* ------------------------------------------------------------------------- */
/* Settings */
/* ------------------------------------------------------------------------- */

/* Settings: Updates Settings UI components */
void MainWindow::UpdateUiComponentsSettings(Jdevice* device) {

  if(device) {
    /* Enable or disable factory set default button */
    ui->pushBtnStFactoryDefaults->setEnabled(device->IsFactoryDefaultSupported());

    /* Update required? */
    if(mSettingListArea.HasCacheBeenInvalidated()) {

      /* Clear current list of settings */
      mSettingListArea.ClearAndDelete();

      if(device->IsLockedLocally()) {

        /* Create a new list of settingWidgets: get device settings and add them to the list */
        DeviceSettings* devSettings = device->GetSettings();
        if(devSettings) {
          mSettingListArea.BuildSettingList(devSettings, ui->scrollAreaSettingsWidget);
        }

        /* Connect slot/signal for setting widgets so we get notified when a setting is changed */
        for(int i=0; i<mSettingListArea.GetSettingsWidgets().count(); ++i) {
          connect(mSettingListArea.GetSettingsWidgets()[i], SIGNAL(signalSettingChanged(SettingWidget*)), this, SLOT(onSettingChanged(SettingWidget*)));
        }
      }
    }

    /* Hide or show note about locking the device */
    ui->labelSettingsLock->setHidden(device->IsLockedLocally());

    /* Enable apply button if change settings are present */
    ui->pushBtnStApply->setEnabled(mSettingListArea.GetSettingsWidgetsChanged().size() > 0);

  } else {

    /* Clear current list of settings */
    mSettingListArea.ClearAndDelete();

    /* Disable apply button */
    ui->pushBtnStApply->setEnabled(false);

    /* Show note about locking the device */
    ui->labelSettingsLock->setHidden(false);
  }
}

/* Settings: Handler for the 'Apply' button */
void MainWindow::on_pushBtnStApply_clicked() {
  const QString errMessage = tr("Error detected when applying the settings");

  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->SetSettings(mSettingListArea.GetSettingsWidgetsChanged());
    if(ret == Return_Ok) {
      showMessage(tr("Setting set successfully"), QString::number(mSettingListArea.GetSettingsWidgetsChanged().count()) + tr(" setting(s) set"));
      ui->pushBtnStApply->setEnabled(false);
      mSettingListArea.ClearChanged();
    }
    else if(ret == Return_ParameterFail) {
      QString errorMessage = tr("Failed to determine failed parameters");
      /* be aware of translation here */
      FailedSettings* fs = Jabra_GetFailedSettingNames(device->GetId());
      if(fs) {
        errorMessage = ":\n";
        for(unsigned int i=0; i<fs->count; i++) {
          qDebug() << *(fs->settingNames + i);
          errorMessage += QString(*(fs->settingNames + i)) + "\n";
        }
        Jabra_FreeFailedSettings(fs);
      }
      showMessage(errMessage, errorMessage);
    }
    else {
      showMessage(errMessage, tr("returned ") + Jdevice::ToString(ret));
    }
  }
}

/* Settings: Handler for the 'Restore factory settings' button */
void MainWindow::on_pushBtnStFactoryDefaults_clicked() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    if(!device->IsLockedLocally()) {
      showMessage(tr("Device is not locked"), "");
      return;
    }

    if(device->GetSettings(false)) {
      bool isDeviceRebootRequired = device->GetSettings(false)->settingInfo->isDeviceRestart;
      if(device->SetFactoryDefaults() == true) {
        showMessage(tr("Factory defaults set successfully"), isDeviceRebootRequired ? tr("device will reboot") : "");
        if(!isDeviceRebootRequired) {
          onDeviceSelected(device);
        }
      } else {
        showMessage(tr("Unable to set factory defaults"), "");
      }
    } else {
      showMessage(tr("No settings available"), "");
    }
  }
}

void MainWindow::onSettingChanged(SettingWidget* setting) {
  mSettingListArea.MarkSettingChanged(setting);
  ui->pushBtnStApply->setEnabled(true);
}

/* ------------------------------------------------------------------------- */
/* Call Control */
/* ------------------------------------------------------------------------- */

/* Call Control: Updates Call Control UI components */
void MainWindow::UpdateUiComponentsCallControl(Jdevice* device) {
  if(device) {
    ui->pushBtnCcOffHook->setEnabled(Jabra_IsOffHookSupported(device->GetId()));
    ui->pushBtnCcOffHook->setText(tr("Off &Hook (%1)").arg(device->GetState().OffHook));
    ui->pushBtnCcRinger->setEnabled(Jabra_IsRingerSupported(device->GetId()));
    ui->pushBtnCcRinger->setText(tr("&Ringer (%1)").arg(device->GetState().Ringer));
    ui->pushBtnCcMute->setEnabled(Jabra_IsMuteSupported(device->GetId()));
    ui->pushBtnCcMute->setText(tr("M&ute (%1)").arg(device->GetState().Mute));
    ui->pushBtnCcHold->setEnabled(Jabra_IsHoldSupported(device->GetId()));
    ui->pushBtnCcHold->setText(tr("O&n Hold (%1)").arg(device->GetState().Hold));
    ui->pushBtnCcAudioLink->setEnabled(Jabra_IsOnlineSupported(device->GetId()));
    ui->pushBtnCcAudioLink->setText(tr("&AudioLink (%1)").arg(device->GetState().AudioLink));
    ui->pushBtnCcBusyLight->setEnabled(device->IsBusylightSupported());
    ui->pushBtnCcBusyLight->setText(tr("Busy&Light (%1)").arg(device->GetState().BusyLight));
    ui->pushBtnCcRefresh->setEnabled(device->IsBatterySupported());
    ui->labelBatteryLevel->setText(tr("Battery level (%): %1").arg(device->IsBatterySupported() ? tr("-") : tr("not supported")));
  } else {
    ui->pushBtnCcOffHook->setEnabled(false);
    ui->pushBtnCcOffHook->setText(tr("Off &Hook"));
    ui->pushBtnCcRinger->setEnabled(false);
    ui->pushBtnCcRinger->setText(tr("&Ringer"));
    ui->pushBtnCcMute->setEnabled(false);
    ui->pushBtnCcMute->setText(tr("M&ute"));
    ui->pushBtnCcHold->setEnabled(false);
    ui->pushBtnCcHold->setText(tr("O&n Hold"));
    ui->pushBtnCcAudioLink->setEnabled(false);
    ui->pushBtnCcAudioLink->setText(tr("&Audio Link"));
    ui->pushBtnCcBusyLight->setEnabled(false);
    ui->pushBtnCcBusyLight->setText(tr("Busy&Light"));
    ui->pushBtnCcRefresh->setEnabled(false);
    ui->labelBatteryLevel->setText(tr("Battery level (%): not supported"));
  }
}

/* Call Control: Handler for the Hook button */
void MainWindow::on_pushBtnCcOffHook_clicked() {
  mMtx.lock();
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    bool tmp = !device->GetState().OffHook;
    Jabra_ReturnCode ret = Jabra_SetOffHook(device->GetId(), tmp);
    if(Return_Ok != ret) {
      showMessage(tr("Error during set Off Hook"), tr("returned ") + Jdevice::ToString(ret));
    } else {
      device->GetState().OffHook = tmp;
    }
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Call Control: Handler for the Mute button */
void MainWindow::on_pushBtnCcMute_clicked() {
  mMtx.lock();
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    bool tmp = !device->GetState().Mute;
    Jabra_ReturnCode ret = Jabra_SetMute(device->GetId(), tmp);
    if(Return_Ok != ret) {
      showMessage(tr("Error during set Mute"), tr("returned ") + Jdevice::ToString(ret));
    } else {
      device->GetState().Mute = tmp;
    }
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Call Control: Handler for the Ringer button */
void MainWindow::on_pushBtnCcRinger_clicked() {
  mMtx.lock();
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    bool tmp = !device->GetState().Ringer;
    Jabra_ReturnCode ret = Jabra_SetRinger(device->GetId(), tmp);
    if(Return_Ok != ret) {
      showMessage(tr("Error during set Ringer"), tr("returned ") + Jdevice::ToString(ret));
    } else {
      device->GetState().Ringer = tmp;
    }
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Call Control: Handler for the Hold button */
void MainWindow::on_pushBtnCcHold_clicked() {
  mMtx.lock();
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    if(device->GetState().Hold) {
      Jabra_ReturnCode ret = Jabra_SetOffHook(device->GetId(), true);
      if(Return_Ok != ret) {
        showMessage(tr("Error during set Off Hook"), tr("returned ") + Jdevice::ToString(ret));
      } else {
        device->GetState().OffHook = true;
        ret = Jabra_SetHold(device->GetId(), false);
        if(Return_Ok != ret) {
          showMessage(tr("Error during set Hold"), tr("returned ") + Jdevice::ToString(ret));
        } else {
          device->GetState().Hold = false;
        }
      }
    }
    else {
      Jabra_ReturnCode ret = Jabra_SetHold(device->GetId(), true);
      if(Return_Ok != ret) {
        showMessage(tr("Error during set Hold"), tr("returned ") + Jdevice::ToString(ret));
      } else {
        device->GetState().Hold = true;
        ret = Jabra_SetOffHook(device->GetId(), false);
        if(Return_Ok != ret) {
          showMessage(tr("Error during set Off Hook"), tr("returned ") + Jdevice::ToString(ret));
        } else {
          device->GetState().OffHook = false;
        }
      }
    }
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Call Control: Handler for the AudioLink button */
void MainWindow::on_pushBtnCcAudioLink_clicked() {
  mMtx.lock();
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    bool tmp = !device->GetState().AudioLink;
    Jabra_ReturnCode ret = Jabra_SetOnline(device->GetId(), tmp);
    if(Return_Ok != ret) {
      showMessage(tr("Error during set AudioLink"), tr("returned ") + Jdevice::ToString(ret));
    } else {
      device->GetState().AudioLink = tmp;
    }
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Call Control: Handler for the BusyLight button */
void MainWindow::on_pushBtnCcBusyLight_clicked() {
  mMtx.lock();
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    bool tmp = !device->GetState().BusyLight;
    Jabra_ReturnCode ret = Jabra_SetBusylightStatus(device->GetId(), tmp);
    if(Return_Ok != ret) {
      showMessage(tr("Error during set BusyLight"), tr("returned ") + Jdevice::ToString(ret));
    } else {
      device->GetState().BusyLight = tmp;
    }
    UpdateUiComponentsCallControl(device);
  }
  mMtx.unlock();
}

/* Call Control: Handler for the Clear button */
void MainWindow::on_pushBtnCcClear_clicked() {
  ui->listBoxCcRaw->clear();
  ui->listBoxCcTranslated->clear();
}

/* Call Control: Handler for the Refresh button */
void MainWindow::on_pushBtnCcRefresh_clicked() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    if(device->IsBatterySupported()) {
      int level;
      bool charging;
      bool batteryLow;
      if(device->GetBatteryStatus(&level, &charging, &batteryLow) == Return_Ok) {
        ui->pushBtnCcRefresh->setEnabled(true);
        /* Format battery status string */
        QString batteryStatus = QString("%1 %2%, %3=%4, %5=%6").arg(tr("Battery level (%): ")).arg(level);
        batteryStatus = batteryStatus.arg(tr("charging")).arg(charging ? tr("yes") : tr("no"));
        batteryStatus = batteryStatus.arg(tr("battery low")).arg(batteryLow ? tr("yes") : tr("no"));
        ui->labelBatteryLevel->setText(batteryStatus);
      }
    }
    else {
      ui->pushBtnCcRefresh->setEnabled(false);
      ui->labelBatteryLevel->setText(tr("Battery level (%): not supported"));
    }
  }
}

/* ------------------------------------------------------------------------- */
/* Bluetooth */
/* ------------------------------------------------------------------------- */

/* Bluetooth: Updates Bluetooth UI components */
void MainWindow::UpdateUiComponentsBluetooth(Jdevice* device) {
  bool paringSupported = (device ? device->IsPairingSupported() : false);

  /* Is BT pairing supported, hide/show header frame */
  ui->frame_18->setHidden(paringSupported);

  /* Enable pairing frame */
  ui->frame_17->setEnabled(paringSupported);

  /* Clear list of paired devices */
  ui->listBoxBtPaired->clear();

  /* Update auto pairing setting */
  ui->checkBoxBtAutoSearch->setChecked(paringSupported ? device->IsAutoPairingSupported() : false);

  /* Display dongle name */
  ui->labelBtConnectedVia->setText(tr("Using dongle ") + (paringSupported ? device->GetDongleName() : "-"));

  bool headsetConnected = paringSupported ? device->IsHeadsetConnected() : false;

  /* Update/enable button text */
  ui->pushBtnBtConnect->setText(headsetConnected ? tr("&Disconnect") : tr("&Reconnect"));

  /* Update connection status */
  ui->labelBtConnectStatus->setVisible(headsetConnected);
  ui->labelBtConnectStatus->setText(headsetConnected ? tr("Connected to ") + device->GetConnectedBtDeviceName() : "");

  /* Build list of paired devices */
  Jabra_PairingList* plist = (paringSupported ? device->GetListOfPairedDevices() : nullptr);
  if(plist != nullptr) {
    /* First row is used as header */
    QString row = QString("%1\t%2").arg(tr("MAC address")).arg(tr("Name"));
    ui->listBoxBtPaired->insertItem(0, row);
    ui->listBoxBtPaired->item(0)->setFlags(ui->listBoxBtPaired->item(0)->flags() & ~Qt::ItemIsSelectable);
    for(unsigned short i = 0; i < plist->count; ++i) {
      ui->listBoxBtPaired->insertItem(1 + i, device->ToString(plist->pairedDevice + i));
    }
  }
  Jabra_FreePairingList(plist);

  /* Update/enable button text */
  ui->pushBtnBtConnect2->setText(headsetConnected ? tr("Disco&nnect") : tr("Co&nnect"));
}

/* Bluetooth: Handler for the Start pairing button */
void MainWindow::on_pushBtnBtStart_clicked() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->StartBtSearch();
    if(Return_Ok == ret) {
      showMessage(tr("Success"), tr("Bluetooth search started"));
    } else {
      showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to start search"));
    }
  }
}

/* Bluetooth: Handler for the Auto Search check button */
void MainWindow::on_checkBoxBtAutoSearch_clicked(bool checked) {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->SetAutoPairing(checked);
    if(Return_Ok == ret) {
      showMessage(tr("Success"), tr("Auto pairing ") + QString(checked ? tr("enabled") : tr("disabled")));
    } else {
      showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to set auto pairing"));
    }
  }
}

/* Bluetooth: Handler for the Connect button */
void MainWindow::on_pushBtnBtConnect_clicked() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    if(device->IsHeadsetConnected()) {
      Jabra_ReturnCode ret = device->DisconnectBluetoothDevice();
      if(Return_Ok == ret) {
        ui->pushBtnBtConnect->setText(tr("&Reconnect"));
      } else {
        showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to disconnect the Bluetooth device"));
      }
    } else {
      Jabra_ReturnCode ret = device->ConnectBluetoothDevice();
      if(Return_Ok == ret) {
        ui->pushBtnBtConnect->setText(tr("&Disconnect"));
      } else {
        showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to connect the Bluetooth device"));
      }
    }
  }
}

/* Bluetooth: Handler for the ClearAll button */
void MainWindow::on_pushBtnBtClearAll_clicked() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->ClearPairingList();
    if(Return_Ok == ret) {
      showMessage(tr("Success"), tr("Bluetooth device pairing list cleared"));
    } else {
      showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to clear Bluetooth device pairing list"));
    }
  }
}

/* Bluetooth: Handler for the Reset button */
void MainWindow::on_pushBtnBtReset_clicked() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->ResetBtAdapter();
    if(Return_Ok == ret) {
      showMessage(tr("Success"), tr("Bluetooth adapter reset"));
    } else {
      showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to reset Bluetooth adapter"));
    }
  }
}

/* Bluetooth: Handler for the Clear button */
void MainWindow::on_pushBtnBtClear_clicked() {
  if(ui->listBoxBtPaired->currentRow() < 1) {
    showMessage("", tr("No device selected in the paired device list"));
    return;
  }

  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_PairingList* plist = device->GetListOfPairedDevices();
    Jabra_PairedDevice* pDevice = device->GetPairedDevice(plist, ui->listBoxBtPaired->currentRow() - 1);
    if(pDevice) {
      Jabra_ReturnCode ret = Jabra_ClearPairedDevice(device->GetId(), pDevice);
      if(Return_Ok == ret) {
        showMessage(tr("Success"), tr("Bluetooth pairing cleared"));
        UpdateUiComponentsBluetooth(device);
      } else {
        showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to clear Bluetooth pairing"));
      }
    }
    Jabra_FreePairingList(plist);
  }
}

/* Bluetooth: Handler for the Connect/disconnect button */
void MainWindow::on_pushBtnBtConnect2_clicked() {
  if(ui->listBoxBtPaired->currentRow() < 1) {
    showMessage("", tr("No device selected"));
    return;
  }

  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_PairingList* plist = device->GetListOfPairedDevices();
    Jabra_PairedDevice* pDevice = device->GetPairedDevice(plist, ui->listBoxBtPaired->currentRow() - 1);
    if(pDevice) {
      if(ui->pushBtnBtConnect2->text() == tr("Co&nnect")) {
        Jabra_ReturnCode ret = Jabra_ConnectPairedDevice(device->GetId(), pDevice);
        if(Return_Ok == ret) {
          showMessage(tr("Success"), tr("Connecting"));
        } else {
          showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to connect"));
        }
      } else {
        Jabra_ReturnCode ret = Jabra_DisConnectPairedDevice(device->GetId(), pDevice);
        if(Return_Ok == ret) {
          showMessage(tr("Success"), tr("Disconnecing"));
        } else {
          showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to disconnect"));
        }
      }
    }
    Jabra_FreePairingList(plist);
  }
}

/* ------------------------------------------------------------------------- */
/* Remote MMI */
/* ------------------------------------------------------------------------- */

/* Remote MMI: Updates remote MMI UI components */
void MainWindow::UpdateUiComponentsMmi(Jdevice* device) {
  bool supported = (device ? device->IsRemoteMmiSupported() : false);
  ui->frame_30->setEnabled(supported);
  ui->frame_26->setHidden(supported);
  if(supported) {
    /* If layout has not been assigned, append UI components */
    if(!mRemoteMmiList) {
      mRemoteMmiList = new RemoteMmiListView(device);
      ui->scrollAreaMmiSupportedWidget->layout()->addWidget(mRemoteMmiList);

      /* Connect slot/signal for MMI widgets so we get notified when a MMI focus change is required */
      connect(mRemoteMmiList, SIGNAL(signalMmiFocusGet(unsigned short, QString, unsigned short, QString, QString)), this, SLOT(onRemoteMmiFocusGet(unsigned short, QString, unsigned short, QString, QString)));
      connect(mRemoteMmiList, SIGNAL(signalMmiFocusRelease(unsigned short, QString, unsigned short, QString)), this, SLOT(onRemoteMmiFocusRelease(unsigned short, QString, unsigned short, QString)));
    }
  } else {
    if(mRemoteMmiList) {

      /* Delete layout */
      delete mRemoteMmiList;
      mRemoteMmiList = nullptr;
    }
    /* Clear events */
    ui->listBoxMmiEvents->clear();
  }
}

/* Remote MMI: Handler for clear button */
void MainWindow::on_pushBtnMmiClear_clicked() {
  ui->listBoxMmiEvents->clear();
}

void MainWindow::onRemoteMmiFocusGet(unsigned short keyType, QString keyValue, unsigned short key, QString value, QString message) {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->GetRemoteMmiButtonFocus(keyType, keyValue, key, value);
    if(Return_Ok == ret) {
      showMessage(tr("Got focus ") + keyValue + ":" + value, "");
      device->AddMmiInFocus(keyType, key, message);
    } else {
      showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to get focus"));
    }
  }
}

void MainWindow::onRemoteMmiFocusRelease(unsigned short keyType, QString keyValue, unsigned short key, QString value) {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  if(device) {
    Jabra_ReturnCode ret = device->ReleaseRemoteMmiButtonFocus(keyType, keyValue, key, value);
    if(Return_Ok == ret) {
      showMessage(tr("Released focus ") + keyValue + ":" + value, "");
      device->RemoveMmiInFocus(keyType, key);
    } else {
      showMessage(tr("Error ") + Jdevice::ToString(ret), tr("Unable to release focus"));
    }
  }
}

/* ------------------------------------------------------------------------- */
/* Common */
/* ------------------------------------------------------------------------- */

/* Common: Updates all UI components */
void MainWindow::UpdateUiComponents() {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  UpdateUiComponentsProductInfo(device);
  UpdateUiComponentsCallControl(device);
  UpdateUiComponentsSettings(device);
  UpdateUiComponentsBluetooth(device);
  UpdateUiComponentsMmi(device);
}

void MainWindow::onDeviceSelected(Jdevice* device) {
  if(device) {
    setCursor(QCursor(Qt::WaitCursor));
    mSettingListArea.InvalidateCache();
    UpdateUiComponents();
    setCursor(QCursor(Qt::ArrowCursor));
  }
}

void MainWindow::onDeviceLocked(Jdevice* device) {
  if(device) {
    if(device->IsLockedLocally()) {
      Jabra_ReturnCode ret = device->Unlock();
      if(Return_Ok != ret) {
        showMessage(tr("Error during unlock device"), tr("returned ") + Jdevice::ToString(ret));
      } else {
        mPreviewArea->SetButtonText(device, tr("Unlocked"));
        mSettingListArea.InvalidateCache();
      }
    } else {
      Jabra_ReturnCode ret = device->Lock();
      if(Return_Ok != ret) {
        showMessage(tr("Error during lock device"), tr("returned ") + Jdevice::ToString(ret));
      } else {
        device->InitializeCallControl();
        mPreviewArea->SetButtonText(device, tr("Locked"));
      }
    }
  }
  /* Update the selected tab */
  if(device == mPreviewArea->GetSelectedDevice()) {
    setCursor(QCursor(Qt::WaitCursor));
    on_tab_currentChanged(ui->tab->currentIndex());
    setCursor(QCursor(Qt::ArrowCursor));
  }
}

void MainWindow::closeEvent(QCloseEvent *ev) {
  if(ui->pushBtnStApply->isEnabled()) {
    if(showMessage(tr("Quit"), tr("Settings not applied, do you really want to exit?"),
                   QMessageBox::Yes | QMessageBox::No) == QMessageBox::No) {
      ev->ignore();
      return;
    }
  }
  ev->accept();
}

enum QMessageBox::StandardButton MainWindow::showMessage(const QString& text, const QString& info, QFlags<QMessageBox::StandardButton> btnMask) {
  QMessageBox msgBox(this);
  msgBox.setText(text);
  msgBox.setInformativeText(info);
  msgBox.setStandardButtons(btnMask);
  return static_cast<QMessageBox::StandardButton>(msgBox.exec());
}

void MainWindow::on_tab_currentChanged(int index) {
  Jdevice* device = mPreviewArea->GetSelectedDevice();
  /* Update selected UI components based upon the active page */
  switch(index) {
    case (0):
      /* Update product info tab */
      UpdateUiComponentsProductInfo(device);
      break;
    case (1):
      /* Update settings tab */
      UpdateUiComponentsSettings(device);
      break;
    case (2):
      /* Update call control tab */
      UpdateUiComponentsCallControl(device);
      break;
    case (3):
      /* Update Bluetooth tab */
      UpdateUiComponentsBluetooth(device);
      break;
    case (4):
      /* Update remote MMI tab */
      UpdateUiComponentsMmi(device);
      break;
  }
}
