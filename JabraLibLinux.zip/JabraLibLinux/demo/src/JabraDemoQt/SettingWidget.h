#ifndef QSETTINGWIDGET_H
#define QSETTINGWIDGET_H

#include <QFrame>
#include <QHBoxLayout>
#include <QMap>
#include "JabraDeviceConfig.h"

/**
 * @brief The SettingWidget wraps a device setting. The widget intepretates the
 * SettingInfo structure and creates a UI widget based upon the control type and
 * fills in possible values and the current value of the setting.
 */
class SettingWidget : public QFrame
{
  Q_OBJECT

  /** @brief GUID of setting. */
  QString mGuid;

  /** @brief Name of setting. */
  QString mName;

  /** @brief Logical group the setting belongs to. */
  QString mGroup;

  /** @brief Type of UI component, radio, list, etc. */
  ControlType mCntrlType;

  /** @brief Is setting value interpretated as a byte value. */
  bool mIsDataTypeByte;

  /** @brief Is setting value interpretated as a string (ASCII) value. */
  bool mIsDataTypeString;

  /** @brief If user input validation is supported. */
  bool mIsValidationSupported;

  /** @brief Used for user input validation (if supported): minimum length of input. */
  unsigned int mValidationMinLength;

  /** @brief Used for user input validation (if supported): maximum length of input. */
  unsigned int mValidationMaxLength;

  /** @brief Used for user input validation (if supported): Regular expression to validate input. */
  QRegExp mValidationRule;

  /** @brief Map with key + value pair for setting values. */
  QMap<unsigned short, QString> mPossibleValues;

  /** @brief Map of map with dependencies. */
  QMap<unsigned short, QMap<QString, bool>> mDependencySetting;

  /** @brief Setting value as a string. */
  QString mValue;

  /** @brief Layout where a setting reside. */
  QHBoxLayout* mHoriz;

  /** @brief Setting control widget, type is determined by #mCntrlType. */
  QWidget* mControlWidget;

  /**
   * @brief Builds the map of #mPossibleValues and #mDependencySetting.
   * @param[in] s the structure to build the map from.
   */
  void buildSettingMap(SettingInfo& s);

  /**
   * @brief Creates a widget based upon the @arg cntrlType passed.
   * @param[in] cntrlType type of widget to create.
   * @return the widget created.
   */
  QWidget* CreateWidget(ControlType cntrlType);

  /**
   * @brief Sets the current value of the setting.
   * @param[in] cntrlType type of control.
   * @param[in] currentValue the value to set as current value.
   */
  void setCurrentValue(ControlType cntrlType, void* currentValue);

  /**
   * @brief Used for emitting a setting changed signal.
   * @param[in] text text selected/entered.
   */
  void settingChanged(const QString& text);

  /**
   * @brief Iterates the mDependencySetting list to see if any widgets should be
   * enabled or disabled.
   * @param[in] text text/value of current selected setting.
   */
  void UpdateDependencies(const QString& text);

  /** @brief Static map of settings, used when each setting is seeking dependencies. */
  static QMap<QString, SettingWidget*> sSettings;

  /**
   * @brief Looks up the SettingWidget that owns the GUID specified by @arg guid. The
   * static map sSettings is used for this purpose. The method is used to find setting
   * dependencies.
   * @param[in] guid GUID to look up.
   * @return reference to the SettingWidget that owns the GUID specified, if no owner
   * is found a nullptr is returned.
   */
  static SettingWidget* LookupByGuid(const QString& guid) {
    return sSettings[guid];
  }

  /**
   * @brief Select current index of widget.
   * @param[in] index index to select.
   */
  void SelectIndex(int index);

public:
  /**
   * @brief Construct a SettingWidget based upon the @arg setting.
   * @param[in] setting setting structure describing a setting.
   * @param[in] parnt parent (owner) widget.
   */
  explicit SettingWidget(SettingInfo& setting, QWidget* parnt = 0);

  /** @brief Descructor, cleans up. */
  ~SettingWidget();

  /**
   * @brief Gets the GUID of the setting.
   * @return the GUID as a string.
   */
  QString GetGuid() const { return mGuid; }

  /**
   * @brief Gets the name of the setting.
   * @return the name of the setting.
   */
  QString GetName() const { return mName; }

  /**
   * @brief Updates the dependencies of the setting (one level) i.e. this
   * setting might have dependencies that needs to be disabled or enabled.
   */
  void UpdateDependencies();

  /**
   * @brief Fills the @arg settingInfo with information about the setting changed.
   * Memory is allocated during the call, this must be freed by calling SettingWidget::Empty.
   * @param[out] settingInfo structure to fill.
   * @return true if call was sucessful.
   */
  bool Fill(SettingInfo* settingInfo) const;

  /**
   * @brief Empties, deallocates, the dynamic memory entires in the @arg settingInfo structure.
   * @param[in] settingInfo
   */
  static void Empty(SettingInfo* settingInfo);

private slots:
  /**
   * @brief Slot emitted when a setting button is pressed.
   */
  void stateChanged();

  /**
   * @brief Slot emitted when a setting is changed. Issued by QComboBox widget.
   * @param[in] text text selected by user.
   */
  void currentIndexChanged(const QString& text);

  /**
   * @brief Slot emitted when a setting is changed. Issued by QLineEdit widget.
   * @param[in] text text entered by user.
   */
  void textChanged(const QString& text);

signals:
  /**
   * @brief Signal emitted when a setting is changed.
   * @param[in] widget reference to widget changed.
   */
  void signalSettingChanged(SettingWidget* widget);

  /**
   * @brief Signal emitted when a setting is activated.
   * @param[in] widget reference to widget changed.
   */
  void signalSettingActivated(SettingWidget* widget);
};

#endif /* QSETTINGWIDGET_H */
