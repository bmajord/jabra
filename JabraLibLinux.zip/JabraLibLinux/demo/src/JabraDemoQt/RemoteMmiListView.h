#ifndef REMOTEMMILISTVIEW_H
#define REMOTEMMILISTVIEW_H

#include "RemoteMmiWidget.h"
#include "Jdevice.h"

class RemoteMmiListView : public QWidget
{
  Q_OBJECT

  /** @brief List of RemoteMmiWidgets present in the layout. */
  QList<RemoteMmiWidget*> mRemoteWidgets;

public:
  /**
   * @brief Constructor for RemoteMmiListView, builds a list of RemoteMmiWidgets.
   * @param[in] jdevice device owner.
   * @param[in] parnt parent widget.
   */
  explicit RemoteMmiListView(Jdevice* jdevice, QWidget* parnt = 0);

  /** @brief Destructor. */
  ~RemoteMmiListView();

  /**
   * @brief Get access to the list of remote MMIs.
   * @return list of remote MMIs that the device supports.
   */
  QList<RemoteMmiWidget*>& GetWidgets() { return mRemoteWidgets; }

private slots:

  /**
   * @brief Slot called when a remote MMI is in focus.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key.
   * @param[in] value key value.
   * @param[in] message message from user input.
   */
  void onMmiFocusGet(unsigned short keyType, QString keyValue, unsigned short key, QString value, QString message);

  /**
   * @brief Slot called when a remote MMI is out of focus.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key.
   * @param[in] value key value.
   */
  void onMmiFocusRelease(unsigned short keyType, QString keyValue, unsigned short key, QString value);

signals:
  /**
   * @brief Signal emitted when a remote MMI is in focus.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key.
   * @param[in] value key value.
   * @param[in] message message from user input.
   */
  void signalMmiFocusGet(unsigned short keyType, QString keyValue, unsigned short key, QString value, QString message);

  /**
   * @brief Signal emitted when a remote MMI is out of focus.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key.
   * @param[in] value key value.
   */
  void signalMmiFocusRelease(unsigned short keyType, QString keyValue, unsigned short key, QString value);
};

#endif /* REMOTEMMILISTVIEW_H */
