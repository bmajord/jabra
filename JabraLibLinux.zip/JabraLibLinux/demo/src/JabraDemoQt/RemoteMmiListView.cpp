#include "RemoteMmiListView.h"
#include "Common.h"
#include "QDebug"

RemoteMmiListView::RemoteMmiListView(Jdevice* jdevice, QWidget *parnt) : QWidget(parnt) {

  setLayout(new QVBoxLayout(parnt));

  if(jdevice) {
    QList<MmiButton> mmiButtons = jdevice->GetSupportedButtonEvents();
    for(int i=0; i<mmiButtons.size(); i++) {
      RemoteMmiWidget* widget = new RemoteMmiWidget(mmiButtons[i]);
      mRemoteWidgets.append(widget);
      this->layout()->addWidget(widget);
      connect(widget, SIGNAL(signalMmiFocusGet(unsigned short, QString, unsigned short, QString, QString)), this, SLOT(onMmiFocusGet(unsigned short, QString, unsigned short, QString, QString)));
      connect(widget, SIGNAL(signalMmiFocusRelease(unsigned short, QString, unsigned short, QString)), this, SLOT(onMmiFocusRelease(unsigned short, QString, unsigned short, QString)));
    }
  }
}

void RemoteMmiListView::onMmiFocusGet(unsigned short keyType, QString keyValue, unsigned short key, QString value, QString message) {
  emit signalMmiFocusGet(keyType, keyValue, key, value, message);
}

void RemoteMmiListView::onMmiFocusRelease(unsigned short keyType, QString keyValue, unsigned short key, QString value) {
  emit signalMmiFocusRelease(keyType, keyValue, key, value);
}

RemoteMmiListView::~RemoteMmiListView() {
  mRemoteWidgets.clear();
}

