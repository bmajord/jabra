#ifndef REMOTEMMIWIDGET_H
#define REMOTEMMIWIDGET_H

#include <QHBoxLayout>
#include <QWidget>
#include <QPushButton>
#include <QComboBox>
#include <QMap>
#include "Common.h"
#include <QVBoxLayout>
#include <QLineEdit>
#include "RemoteMmiDefinitions.h"

class RemoteMmiWidget : public QWidget
{
  Q_OBJECT

  /** @brief key type selection. */
  QComboBox* mComboBox;

  /** @brief User input field for message. */
  QLineEdit* mLineEdit;

  /** @brief Map of supported event types for this MMI. Used for building list. */
  QMap<unsigned short, struct MmiButton> mMmiButtonSupported;

  /** @brief mMmiButton remote MMI button capability. */
  struct MmiButton mMmiButton;

public:
  /**
   * @brief Constructor, build the widget with information from @arg btn.
   * @param[in] btn button capabilities.
   * @param[in] parnt parent widget.
   */
  explicit RemoteMmiWidget(MmiButton btn, QWidget *parnt = 0);

private slots:

  /**
   * @brief Slot emitted when the GetFocus button is pressed.
   */
  void onClickedFocusGet();

  /**
   * @brief Slot emitted when the ReleaseFocus button is pressed.
   */
  void onClickedFocusRelease();

signals:
  /**
   * @brief Signal emitted when the GetFocus button is pressed.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key.
   * @param[in] value key value.
   * @param[in] message message from user input.
   */
  void signalMmiFocusGet(unsigned short keyType, QString keyValue, unsigned short key, QString value, QString message);

  /**
   * @brief Signal emitted when the ReleaseFocus button is pressed.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key value.
   * @param[in] value key value.
   */
  void signalMmiFocusRelease(unsigned short keyType, QString keyValue, unsigned short key, QString value);
};

#endif /* REMOTEMMIWIDGET_H */
