#ifndef REMOTEMMIDEFINITIONS_H
#define REMOTEMMIDEFINITIONS_H

#include <QString>
#include <QMap>

struct MmiButton {
 unsigned short id;
 QString name;
 QMap<unsigned short, QString> events;
};

#endif /* REMOTEMMIDEFINITIONS_H */
