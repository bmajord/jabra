#include "ThumbListView.h"
#include <QPushButton>
#include <QDebug>

ThumbListView::ThumbListView(QWidget* parnt) : QWidget(parnt), mSelectedDevice(nullptr) {
  mLayout = new QVBoxLayout();
  mLayout->setGeometry(QRect(0, 0, parnt->width(), parnt->minimumSizeHint().height()));
  mLayout->setAlignment(Qt::AlignTop);
  mLayout->setContentsMargins(0, 0, 0, 0);
  mLayout->setSpacing(0);
  mLayout->setMargin(0);
  parnt->setLayout(mLayout);
}

ThumbListView::~ThumbListView() {
  QMap<Jdevice*, QPair<QPushButton*, QPushButton*>>::iterator i;
  for(i = mDevices.begin(); i != mDevices.end(); ++i) {
    delete i.value().first;
    delete i.value().second;
    delete i.key();
  }
}

void ThumbListView::OnDeviceSelected() {
  QPushButton* sndr = qobject_cast<QPushButton*>(this->sender());
  QMap<Jdevice*, QPair<QPushButton*, QPushButton*>>::iterator i;

  for(i = mDevices.begin(); i != mDevices.end(); ++i) {
    if(i.value().first == sndr) {
      if(i.key()) {
        if(mSelectedDevice) {
          /* deselect previous device */
          mDevices[mSelectedDevice].first->setChecked(false);
        }
        mSelectedDevice = i.key();
        mDevices[mSelectedDevice].first->setChecked(true);
        emit DeviceSelected(i.key());
      }
      break;
    }
  }
}

void ThumbListView::OnDeviceLocked() {
  QMap<Jdevice*, QPair<QPushButton*, QPushButton*>>::iterator i;

  for(i = mDevices.begin(); i != mDevices.end(); ++i) {
    if(i.value().second == qobject_cast<QPushButton*>(this->sender())) {
      if(i.key()) {
        emit DeviceLocked(i.key());
      }
      break;
    }
  }
}

void ThumbListView::RemoveDevice(unsigned short id) {
  QMap<Jdevice*, QPair<QPushButton*, QPushButton*>>::iterator i;

  for(i = mDevices.begin(); i != mDevices.end(); ++i) {
    if(i.key() && i.key()->GetId() == id) {
      if(mSelectedDevice == i.key()) {
        mSelectedDevice = nullptr;
      }
      delete i.value().first;
      delete i.value().second;
      delete i.key();
      mDevices.erase(i);

      /* auto select if only one device in list */
      if(mDevices.size() == 1) {
        mSelectedDevice = mDevices.keys().at(0);
        mDevices[mSelectedDevice].first->setChecked(true);
        emit DeviceSelected(mSelectedDevice);
        }
      break;
    }
  }
}

Jdevice* ThumbListView::GetSpecificDevice(unsigned short deviceID) {
  QMap<Jdevice*, QPair<QPushButton*, QPushButton*>>::iterator i;

  for(i = mDevices.begin(); i != mDevices.end(); ++i) {
    if(i.key() && i.key()->GetId() == deviceID) {
      return i.key();
    }
  }
  return nullptr;
}

void ThumbListView::AddDevice(Jdevice* device) {
  if(device == nullptr) {
    return;
  }

  QPushButton* btn = new QPushButton();
  QIcon icn = QIcon();
  icn.addPixmap(device->GetThumbImage(), QIcon::Normal, QIcon::On);
  btn->setIcon(icn);
  btn->setIconSize(device->GetThumbImage().rect().size());
  btn->setFlat(true);
  btn->setFocusPolicy(Qt::StrongFocus);
  btn->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
  btn->setCheckable(true);
  connect(btn, SIGNAL(clicked(void)), this, SLOT(OnDeviceSelected(void)));

  QPushButton* btnLock = new QPushButton();
  btnLock->setGeometry(QRect(0, 0, btn->width(), btn->height()));

  QString txt = tr("Device Id\n%1\nLock").arg(QString::number(device->GetId()));
  btnLock->setText(txt);
  connect(btnLock, SIGNAL(clicked(void)), this, SLOT(OnDeviceLocked(void)));

  QBoxLayout* hLayout = new QHBoxLayout();
  hLayout->setSpacing(0);
  hLayout->setMargin(0);

  hLayout->addWidget(btn, 0, Qt::AlignLeft);
  hLayout->addWidget(btnLock, 0, Qt::AlignLeft);
  mLayout->addLayout(hLayout);

  /* store references */
  mDevices[device] = QPair<QPushButton*, QPushButton*>(btn, btnLock);

  /* auto select if only one device in list */
  if(mSelectedDevice == nullptr) {
    mSelectedDevice = device;
    mDevices[mSelectedDevice].first->setChecked(true);
    emit DeviceSelected(mSelectedDevice);
  }
}

void ThumbListView::SelectDevice(Jdevice* device) {
  if(device == nullptr) {
    return;
  }
  mDevices[device].first->setFocus();
  mDevices[device].first->click();
}

void ThumbListView::SetButtonText(Jdevice* device, const QString& text) {
  QString txt = tr("Device Id\n%1\n%2").arg(QString::number(device->GetId())).arg(text);
  mDevices[device].second->setText(txt);
}
