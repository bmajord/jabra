#include "SettingWidget.h"
#include <QLabel>
#include <QDebug>
#include <QMap>
#include <QComboBox>
#include <QLineEdit>
#include <QListWidget>
#include <QPushButton>
#include <QRadioButton>

#include <stdlib.h>

/* Static initializer location */
QMap<QString, SettingWidget*> SettingWidget::sSettings;

SettingWidget::SettingWidget(SettingInfo& s, QWidget* parnt) : QFrame(parnt),
    mGuid(s.guid),
    mName(s.name),
    mGroup(s.groupName),
    mCntrlType(cntrlUnknown),
    mIsDataTypeByte(false),
    mIsDataTypeString(false),
    mIsValidationSupported(false),
    mValidationMinLength(0),
    mValidationMaxLength(0),
    mHoriz(nullptr),
    mControlWidget(nullptr) {

  /* Add to static map, used for dependency lookup by class instances */
  sSettings[mGuid] = this;

  /* Build internal map of possible values and dependencies */
  buildSettingMap(s);

  /* Create new horizontal layout */
  mHoriz = new QHBoxLayout(this);

  /* Add widgets to it, here the name of the setting as QLabel */
  mHoriz->addWidget(new QLabel(s.name));

  /* Add widget, type of widget depends of setting type */
  QWidget* settingValueWidget = CreateWidget(s.cntrlType);
  if(settingValueWidget) {
    mHoriz->addWidget(settingValueWidget);
    settingValueWidget->setParent(this);
  }

  /* Set current value */
  setCurrentValue(s.cntrlType, s.currValue);

  /* Add tooltip */
  if(s.helpText) {
    /* translated by setting XML */
    QString tip = QString("<b>") + s.name + QString("</b><br>");
    tip += s.helpText;
    this->setToolTip(tip);
  }

  /* Add the horizontal layout to the inner frame */
  this->setLayout(mHoriz);
}

SettingWidget::~SettingWidget() {
  /* cleanup */
  sSettings.remove(mGuid);
  mPossibleValues.clear();
  mDependencySetting.clear();
}

void SettingWidget::stateChanged() {
  /* emit signal */
  emit signalSettingActivated(this);
}

void SettingWidget::currentIndexChanged(const QString& text) {
  /* call to emit signal */
  settingChanged(text);
}

void SettingWidget::textChanged(const QString& text) {
  /* call to emit signal */
  settingChanged(text);
}

void SettingWidget::settingChanged(const QString& text) {
  /* store new text */
  mValue = text;
  /* update dependencies of selected/changed text/setting */
  UpdateDependencies(text);
  /* emit signal */
  emit signalSettingChanged(this);
}

void SettingWidget::buildSettingMap(SettingInfo& s) {
  if(s.listKeyValue && s.listSize > 0) {
    /* Set possible values */
    for(int v = 0; v < s.listSize; v++) {
      mPossibleValues[s.listKeyValue[v].key] = QString(static_cast<char*>(s.listKeyValue[v].value));
      if(s.listKeyValue[v].dependents) {
        for(int i = 0; i < s.listKeyValue[v].dependentcount; i++) {
          mDependencySetting[s.listKeyValue[v].key][s.listKeyValue[v].dependents[i].GUID] = s.listKeyValue[v].dependents[i].enableFlag;
        }
      }
    }
  }
  /* Set data type */
  mIsDataTypeString = (s.settingDataType == settingString);
  mIsDataTypeByte = (s.settingDataType == settingByte);

  /* Set control type */
  mCntrlType = s.cntrlType;

  /* Set validation rule, if supported and present */
  mIsValidationSupported = (s.isValidationSupport && s.validationRule);
  if(mIsValidationSupported) {
    if(s.validationRule->regExp) {
      mValidationRule = QRegExp(s.validationRule->regExp);
    }
    mValidationMinLength = s.validationRule->minLength;
    mValidationMaxLength = s.validationRule->maxLength;
  }

  /* Special case */
  if(mName == "Preferred softphone") {
    /* TODO got this as mIsDataTypeByte, interpretate as string */
    mPossibleValues[0] = QString(static_cast<char*>(s.currValue));
  }
}

void SettingWidget::setCurrentValue(ControlType cntrlType, void* currValue) {
  if(currValue == nullptr) {
    qCritical() << "currValue is NULL" << mName;
  }

  /* set widget display text from value and connect signals if it makes sense */
  switch(cntrlType) {
    case cntrlRadio:
    case cntrlToggle:
    case cntrlComboBox:
    case cntrlDrpDown:
      if(currValue && mIsDataTypeByte) {
        unsigned char value = *static_cast<unsigned char*>(currValue);
        mValue = QString::number(value);
        int index = qobject_cast<QComboBox*>(mControlWidget)->findData(value);
        if(index != -1) {
          qobject_cast<QComboBox*>(mControlWidget)->setCurrentIndex(index);
        }
        connect(mControlWidget, SIGNAL(currentIndexChanged(const QString&)), this, SLOT(currentIndexChanged(const QString&)));
      }
      if(mIsDataTypeString && currValue) {
        qDebug() << "missing";
      }
      break;
    case cntrlLabel:
      if(currValue && mIsDataTypeByte) {
        qDebug() << "missing";
      }
      if(currValue && mIsDataTypeString) {
        mValue = static_cast<char*>(currValue);
        qobject_cast<QLabel*>(mControlWidget)->setText(mValue);
      }
      break;
    case cntrlTextBox:
      if(currValue && mIsDataTypeByte) {
        qDebug() << "missing";
      }
      if(currValue && mIsDataTypeString) {
        mValue = static_cast<char*>(currValue);
        qobject_cast<QLineEdit*>(mControlWidget)->setText(mValue);
      }
      /* If validation is supported, add it to the QLineEdit widget */
      if(mIsValidationSupported && !mValidationRule.isEmpty()) {
        qobject_cast<QLineEdit*>(mControlWidget)->setValidator(new QRegExpValidator(mValidationRule, mControlWidget));
      }
      qobject_cast<QLineEdit*>(mControlWidget)->setMaxLength(mValidationMaxLength);
      connect(mControlWidget, SIGNAL(textChanged(const QString&)), this, SLOT(textChanged(const QString&)));
      break;
    case cntrlButton:
      if(currValue && mIsDataTypeByte) {
        qDebug() << "missing";
      }
      if(currValue && mIsDataTypeString) {
        mValue = static_cast<char*>(currValue);
        qobject_cast<QPushButton*>(mControlWidget)->setText(mValue);
      }
      connect(mControlWidget, SIGNAL(clicked()), this, SLOT(stateChanged()));
      break;
    case cntrlUnknown:
      qCritical() << "Unhandled cntrlUnknown";
      break;
    default:
      qCritical() << "Unhandled ControlType";
      break;
  }
}

QWidget* SettingWidget::CreateWidget(ControlType cntrlType) {

  /* create widgets by cntrlType */
  switch(cntrlType) {
    case cntrlRadio:
    case cntrlToggle:
    case cntrlComboBox:
    case cntrlDrpDown:
      mControlWidget = new QComboBox();
      /* add the possible values */
      for(QMap<unsigned short, QString >::iterator i = mPossibleValues.begin(); i != mPossibleValues.end(); ++i) {
        qobject_cast<QComboBox*>(mControlWidget)->addItem(i.value(), i.key());
      }
      break;
    case cntrlLabel:
      mControlWidget = new QLabel();
      break;
    case cntrlTextBox:
      mControlWidget = new QLineEdit();
      break;
    case cntrlButton:
      mControlWidget = new QPushButton();
      break;
    case cntrlUnknown:
      mControlWidget = new QRadioButton();
      break;
    default:
      break;
  }
  return mControlWidget;
}

void SettingWidget::UpdateDependencies(const QString& text) {
  if(mDependencySetting.isEmpty()) {
    return;
  }

  for(QMap<unsigned short, QString >::iterator i = mPossibleValues.begin(); i != mPossibleValues.end(); ++i) {
    if(i.value() == text) {
      if(mDependencySetting.contains(i.key())) {
        QMap<QString, bool>::const_iterator j = mDependencySetting[i.key()].constBegin();
        SettingWidget* widget = this->LookupByGuid(j.key());
        if(widget) {
          widget->SelectIndex(i.key());
          widget->setEnabled(j.value());
          signalSettingChanged(widget);
        }
      }
      break;
    }
  }
}

void SettingWidget::UpdateDependencies() {
  if(mDependencySetting.isEmpty()) {
    return;
  }

  for(QMap<unsigned short, QString >::const_iterator i = mPossibleValues.begin(); i != mPossibleValues.end(); ++i) {
    if(QString::number(i.key()) == mValue) {
      QMap<QString, bool>::const_iterator j = mDependencySetting[i.key()].constBegin();
      SettingWidget* widget = this->LookupByGuid(j.key());
      if(widget) {
        widget->setEnabled(j.value());
      }
      break;
    }
  }
}


void SettingWidget::SelectIndex(int index) {
  switch(mCntrlType) {
    case cntrlRadio:
    case cntrlToggle:
    case cntrlComboBox:
    case cntrlDrpDown:
      qobject_cast<QComboBox*>(mControlWidget)->setCurrentIndex(index);
      break;
    case cntrlLabel:
    case cntrlTextBox:
    case cntrlButton:
    case cntrlUnknown:
    default:
      break;
  }
}

bool SettingWidget::Fill(SettingInfo* settingInfo) const {
  if(mIsDataTypeByte) {
    settingInfo->settingDataType = settingByte;
    QVariant qdata = qobject_cast<QComboBox*>(mControlWidget)->itemData(qobject_cast<QComboBox*>(mControlWidget)->currentIndex());
    settingInfo->currValue = calloc(1, sizeof(void*));
    if(settingInfo->currValue) {
      int value = qdata.toInt();
      if(value > 255 || value < 0) {
        qCritical() << "Value does not fit";
      }
      else {
        *static_cast<unsigned char*>(settingInfo->currValue) = static_cast<unsigned char>(value);
      }
    } else {
      qCritical() << "Mem alloc error";
      return false;
    }
  }
  else if(mIsDataTypeString) {
    settingInfo->settingDataType = settingString;
    settingInfo->currValue = static_cast<char*>(calloc(1, mValue.length() + 1));
    if(settingInfo->currValue) {
      (void)memcpy(settingInfo->currValue, mValue.toStdString().c_str(), mValue.length());
    } else {
      qCritical() << "Mem alloc error";
      return false;
    }
  }
  settingInfo->cntrlType = mCntrlType;
  settingInfo->guid = static_cast<char*>(calloc(1, mGuid.length() + 1));
  if(settingInfo->guid) {
    (void)memcpy(settingInfo->guid, mGuid.toStdString().c_str(), mGuid.length());
  } else {
    qCritical() << "Mem alloc error";
    return false;
  }
  return true;
}

void SettingWidget::Empty(SettingInfo* settingInfo) {
  free(settingInfo->currValue);
  settingInfo->currValue = nullptr;
  free(static_cast<void*>(settingInfo->guid));
  settingInfo->guid = nullptr;
}
