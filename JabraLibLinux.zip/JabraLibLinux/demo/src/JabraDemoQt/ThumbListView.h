#ifndef THUMBLISTVIEW_H
#define THUMBLISTVIEW_H

#include <QWidget>
#include <QHBoxLayout>
#include <QPushButton>
#include <QMap>
#include "JabraDeviceConfig.h"
#include "Jdevice.h"

/**
 * @brief The ThumbListView class is responsible for displaying the attached Jabra devices. Each
 * device has two buttons associated: one button for selecting the device (makes it possible to
 * read device information, settings, etc.) and one button for locking (makes it possible to
 * write the device) and unlocking. The locking mechanism is OS wide i.e. if the device is locked
 * in one application it cannot be locked in another application on the same machine.
 */
class ThumbListView : public QWidget
{
  Q_OBJECT

  /** @brief Layout containing QPushButton widgets (one for each device). */
  QBoxLayout* mLayout;

  /** @brief Map of devices attached. Two QPushButton widgets for each device. */
  QMap<Jdevice*, QPair<QPushButton*, QPushButton*>> mDevices;

  /** @brief Currently selected device. */
  Jdevice* mSelectedDevice;

public:
  /**
   * @brief Constructor for ThumbListView.
   * @param[in] parent parent widget.
   */
  explicit ThumbListView(QWidget* parent = 0);

  ~ThumbListView();

  /**
   * @brief Adds a device to the ThumbListView.
   * @param[in] device device to add.
   */
  void AddDevice(Jdevice* device);

  /**
   * @brief Removes a device from the list view.
   * @param[in] deviceId id of device to remove.
   */
  void RemoveDevice(unsigned short deviceId);

  /**
   * @brief Gets the device with id deviceId.
   * @param[in] deviceId id of device to get.
   * @return device instance.
   */
  Jdevice* GetSpecificDevice(unsigned short deviceId);

  /**
   * @brief Gets the currently selected device.
   * @return a reference to the currently selected device.
   */
  Jdevice* GetSelectedDevice() const { return mSelectedDevice; }

  /**
   * @brief Gets the number of devices in the list view.
   * @return the number of devices in the list view.
   */
  int GetNumberOfDevices() const { return mDevices.count(); }

  /**
   * @brief Selects a device (as current) from the list view.
   * @param[in] device device to select as current device.
   */
  void SelectDevice(Jdevice* device);

  /**
   * @brief Sets the text of the lock button.
   * @param[in] device device to set text of.
   * @param[in] text text to set.
   */
  void SetButtonText(Jdevice* device, const QString& text);

signals:
  /**
   * @brief Signal that is emitted when the user presses the
   * device QPushButton with picture.
   * @param[in] device the selected device.
   */
  void DeviceSelected(Jdevice* device);

  /**
   * @brief Signal that is emitted when the user presses the
   * device QPushButton with text.
   * @param[in] device the selected device.
   */
  void DeviceLocked(Jdevice* device);

public slots:
  /**
   * @brief Slot that is invoked when the device is selected.
   */
  void OnDeviceSelected();

  /**
   * @brief Slot that is invoked when the device lock button is pressed.
   */
  void OnDeviceLocked();
};

#endif /* THUMBLISTVIEW_H */
