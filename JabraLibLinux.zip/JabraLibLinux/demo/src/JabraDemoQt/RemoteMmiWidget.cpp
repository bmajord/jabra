#include "RemoteMmiWidget.h"

#include <QComboBox>
#include <QHBoxLayout>
#include <QDebug>
#include <QLabel>
#include <QPushButton>

RemoteMmiWidget::RemoteMmiWidget(MmiButton btn, QWidget *parnt) : QWidget(parnt), mMmiButton(btn) {
  QHBoxLayout* hlayout = new QHBoxLayout();

  QWidget* label = new QLabel(btn.name);
  hlayout->addWidget(label, 0, Qt::AlignLeft);

  mComboBox = new QComboBox();
  for(int i=0; i<mMmiButton.events.size(); i++) {
    mComboBox->addItem(mMmiButton.events.value(i), mMmiButton.events[i]);
  }
  hlayout->addWidget(mComboBox, 0, Qt::AlignLeft);

  QPushButton* getFocusButton = new QPushButton();
  getFocusButton->setText(tr("Get focus"));
  hlayout->addWidget(getFocusButton, 0, Qt::AlignLeft);
  connect(getFocusButton, SIGNAL(clicked()), this, SLOT(onClickedFocusGet()));

  QPushButton* releaseFocusButton = new QPushButton();
  releaseFocusButton->setText(tr("Release focus"));
  hlayout->addWidget(releaseFocusButton, 0, Qt::AlignLeft);
  connect(releaseFocusButton, SIGNAL(clicked()), this, SLOT(onClickedFocusRelease()));

  mLineEdit = new QLineEdit();
  mLineEdit->setText("");
  hlayout->addWidget(mLineEdit, 0, Qt::AlignLeft);

  this->setLayout(hlayout);
}

void RemoteMmiWidget::onClickedFocusGet() {
  /* emit focus get signal */
  emit signalMmiFocusGet(mMmiButton.id, mMmiButton.name, (unsigned short)mComboBox->itemData(mComboBox->currentIndex()).toInt(), mComboBox->currentText(), mLineEdit->text());
}

void RemoteMmiWidget::onClickedFocusRelease() {
  /* emit focus release signal */
  emit signalMmiFocusRelease(mMmiButton.id, mMmiButton.name, (unsigned short)mComboBox->itemData(mComboBox->currentIndex()).toInt(), mComboBox->currentText());
}
