#ifndef JABRADEVICE_H
#define JABRADEVICE_H

#include "JabraDeviceConfig.h"
#include <QString>
#include <QPixmap>
#include <QMap>
#include "SettingWidget.h"
#include "RemoteMmiWidget.h"
#include "RemoteMmiDefinitions.h"

struct DeviceState {
  bool OffHook;
  bool Mute;
  bool Ringer;
  bool Hold;
  bool AudioLink;
  bool BusyLight;
};

/**
 * @brief The Jdevice class is a combined container, cache and utility class
 * for dealing with the Jabra device and the API.
 */
class Jdevice
{
  /** @brief API id of device, used as parameter when calling API methods. */
  unsigned short mId;

  /** @brief USB product ID. */
  unsigned short mPid;

  /** @brief Device firmware version. */
  unsigned short mVersion;

  /** @brief Device product name. */
  QString mName;

  /** @brief Device USB path, OS dependent. */
  QString mUsbPath;

  /** @brief Device instance ID, unused. */
  QString mInstanceId;

  /** @brief Jabra product image (format png, resolution 380x380). */
  QPixmap mImage;

  /** @brief Small Jabra product image (format png, resolution 80x80). */
  QPixmap mThumbImage;

  /** @brief Is device locked by this application. */
  bool mLockedLocally;

  /** @brief State of call control. */
  DeviceState mState;

  /** @brief Has device been initialized. */
  bool mIsInitialized;

  /** @brief Placeholder for settings got via API. */
  DeviceSettings* mDeviceSettings;

  /** @brief Name of Bluetooth dongle. */
  QString mDongleName;

  /** @brief Autopairing setting, can be on(=true) or off(=false). */
  bool mAutoPairing;

  /** @brief Bluetooth pairing possible, applicable for Bluetooth devices. */
  bool mIsPairable;

  /** @brief Headset connected status, applicable for Bluetooth devices. */
  bool mHeadsetConnected;

  /** @brief Battery status information is supported. */
  bool mIsBatterySupported;

  /** @brief Busy light is supported. */
  bool mBusyLightSupported;

  /** @brief Remote MMI is supported. */
  bool mMmiSupported;

  /** @brief Remote MMIs in focus. */
  QMap<QPair<unsigned short, unsigned short>, QString> mMmiInFocus;

  /**
   * @brief Fill structure with values that are modified.
   * @param[in,out] deviceSettings sturcture to be filled.
   * @param[in] listSettings settings to fill the structure with.
   * @return true if call was sucessful.
   */
  static bool FillSettingStruct(DeviceSettings* deviceSettings,  QList<SettingWidget*>& listSettings);

  /**
   * @brief Free structure got via API.
   * @param deviceSettings structure to be freed.
   * @param listSettings
   */
  static void FreeSettingStruct(DeviceSettings* deviceSettings,  QList<SettingWidget*>& listSettings);

public:

  /**
   * @brief Constructs a Jdevice instance containing information passed by the
   * attach callback.
   * @param[in] id id (API id) of device.
   * @param[in] pid the USB product id of the device.
   * @param[in] name the name of the device.
   * @param[in] usbPath the USB (driver level) path of the device.
   * @param[in] instanceId the device id (not used in Linux).
   * @param[in] isPairable is the device pariable.
   * @param[in] dongleName name of the dongle (if this device is a dongle).
   */
  explicit Jdevice(unsigned short id, unsigned short pid, const QString& name,
                   const QString& usbPath, const QString& instanceId,
                   bool isPairable, const QString& dongleName);

  /** @brief Destructor. */
  ~Jdevice();

  /**
   * @brief Initialize device, read device capabilities and get pictures.
   */
  void Init();

  /**
   * @brief Get device id (API id).
   * @return the devive id.
   */
  unsigned short GetId() const { return mId; }

  /**
   * @brief Get device name
   * @return name of device.
   */
  const QString& GetName() const { return mName; }

  /**
   * @brief Get the name of the Bluetooth dongle.
   * @return name of the dongle.
   */
  const QString& GetDongleName() const { return mDongleName; }

  /**
   * @brief Get the Jabra product image.
   * @return reference to image.
   */
  const QPixmap& GetImage() const;

  /**
   * @brief Get the small Jabra product (thumb) image.
   * @return reference to image.
   */
  const QPixmap& GetThumbImage() const { return mThumbImage; }

  /**
   * @brief Lock device, gain OS level lock.
   * @return Jabra_ReturnCode see interface for possible return values.
   */
  Jabra_ReturnCode Lock();

  /**
   * @brief Unlock device.
   * @return Jabra_ReturnCode see interface for possible return values.
   */
  Jabra_ReturnCode Unlock();

  /**
   * @brief  Determines if the device is locked or not. It does not tell if
   * the device is locked by this program instance or antoher instance. Use
   * @fn Lock to determine this.
   * @return true if device is locked, false if not locked.
   */
  bool IsLocked();

  /**
   * @brief Is the device locked by this demo application.
   * @return true if the device is locked by this demo application.
   */
  bool IsLockedLocally() const { return mLockedLocally; }

  /**
   * @brief Gets the device settings structure.
   * @param refresh if true reads settings from the device, if false cached
   * settings are used.
   * @return the reference to the settings structure.
   */
  DeviceSettings* GetSettings(bool refresh = true);

  /**
   * @brief Get state of call control.
   * @return reference to call control state.
   */
  DeviceState& GetState() { return mState; }

  /**
   * @brief Has the device been initialized.
   * @return true if the device has been initialized.
   */
  bool IsInitialized() const { return mIsInitialized; }

  /**
   * @brief Initializes call control.
   * @return true if call control is initialized, false if not (an error might have occurred).
   */
  bool InitializeCallControl();

  /**
   * @brief Sets the settings given in the @arg listOfChangedSettings parameter.
   * @param[in] listOfChangedSettings list of settings to set.
   * @return Jabra_ReturnCode see interface for possible return values.
   */
  Jabra_ReturnCode SetSettings(QList<SettingWidget*>& listOfChangedSettings) const;

  /**
   * @brief Sets factory default settings.
   * @return true if factory default settings was applied successfully, false if not.
   */
  bool SetFactoryDefaults() const;

  /**
   * @brief Is setting of factory default settings supported.
   * @return true if factory default setting is supported, false if not.
   */
  bool IsFactoryDefaultSupported() const;

  /**
   * @brief Is the device supporting Bluetooth pairing.
   * @return true if the device supports Bluetooth pairing, false if not.
   */
  bool IsPairingSupported() const { return mIsPairable; }

  /**
   * @brief Is Bluetooth auto pairing enabled.
   * @return true if auto pairing is enabled, disabled if false.
   */
  bool IsAutoPairingSupported() const { return mAutoPairing; }

  /**
   * @brief Sets the state of headset connected.
   * @param[in] connected new state of headset connected.
   */
  void SetHeadsetConnected(bool connected) { mHeadsetConnected = connected; }

  /**
   * @brief Is a Bluetooth headset connected.
   * @return true if a Bluetooth headset is connected.
   */
  bool IsHeadsetConnected() const { return mHeadsetConnected; }

  /**
   * @brief Is battery status information supported.
   * @return true if battery status information is supported.
   */
  bool IsBatterySupported() { return mIsBatterySupported; }

  /**
   * @brief Search for available Bluetooth devices which are switched on,
   * within range and ready to connect.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode StartBtSearch();

  /**
   * @brief When Bluetooth adapter is plugged into the PC it will attempt to
   * connect with the last connected Bluetooth device. If it cannot connect,
   * it will automatically search for new Bluetooth devices to connect to.
   * @param[in] enable enable or disable for auto pairing.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode SetAutoPairing(bool enable);

  /**
   * @brief Clear list of paired Bluetooth devices from adaptor.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode ClearPairingList();

  /**
   * @brief Resets the Bluetooth adapter, device might reboot.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode ResetBtAdapter();

  /**
   * @brief Get friendly name of connected Bluetooth device with adapter.
   * @return Friendly name of connected Bluetooth device.
   */
  QString GetConnectedBtDeviceName();

  /**
   * @brief Connect/Reconnect Bluetooth device to the Jabra Bluetooth adapter.
   * Please ensure that the Bluetooth device is switched on and within range.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode ConnectBluetoothDevice();

  /**
   * @brief Disconnect Bluetooth device from adapter.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode DisconnectBluetoothDevice();

  /**
   * @brief Gets the list of all paired devices.
   * @return pointer to struct holding friendly name and MAC address of paired devices.
   */
  Jabra_PairingList* GetListOfPairedDevices();

  /**
   * @brief Gets the struct of the device containing paired device with
   * index @arg index from @arg pairedList (got by calling Jabra_GetPairingList).
   * @param[in] pairedList device pairing list pointer.
   * @param[in] index index in @arg pairedList list, starts from 0 to size of list - 1.
   * @return pointer to struct containing paried device info. If @arg index is out of range,
   * nullptr is returned.
   */
  Jabra_PairedDevice* GetPairedDevice(Jabra_PairingList* pairedList, int index);

  /**
   * @brief Gets the status of the battery (if supported).
   * @param[out] levelInPercent battery charge level in percent, range is 0 to 100.
   * @param[out] charging true if the battery is being changed, false otherwise.
   * @param[out] batteryLow true if the battery charge level is low detected by the device as begin low.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode GetBatteryStatus(int* levelInPercent, bool* charging, bool* batteryLow);

  /**
   * @brief Is busy light supported by the device.
   * @return true if busy light is supported.
   */
  bool IsBusylightSupported() { return mBusyLightSupported; }

  /**
   * @brief Is remote MMI supported by the device.
   * @return true if remote MMI is supported, false if not.
   */
  bool IsRemoteMmiSupported() { return mMmiSupported; }

  /**
   * @brief Gets focus of remote MMI buttons i.e. events are posted via
   * the callback provided via Jabra_RegisterForGNPButtonEvent.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode GetRemoteMmiButtonFocus(unsigned short typeKey, QString typeValue, unsigned short key, QString value);

  /**
   * @brief Releases focus of remote MMI buttons i.e. event posting
   * is disabled and buttons can be used for normal call control.
   * @return see interface file for a list of possible return values.
   */
  Jabra_ReturnCode ReleaseRemoteMmiButtonFocus(unsigned short typeKey, QString typeValue, unsigned short key, QString value);

  /**
   * @brief Returns the string representation of a paired device i.e.
   * the Bluetooth friendly name and MAC address.
   * @param[in] pDevice pointer to paired device information.
   * @return the friendly name and MAC address in a human readable format.
   */
  QString ToString(const Jabra_PairedDevice* pDevice);

  /**
   * @brief Returns the MAC address of a paired device raw format entry.
   * @param[in] mac pointer to MAC address in raw format.
   * @return the MAC address in a human readable format.
   */
  QString ToMACString(char *mac);

  /**
   * @brief Returns the string representation of the Jabra_ReturnCode.
   * @param[in] code return code to get the string representation of.
   * @return the return code as a string.
   */
  static const QString ToString(Jabra_ReturnCode code);

  /**
   * @brief Get a list of supported remote MMI events.
   * @return list of supported events.
   */
  QList<MmiButton> GetSupportedButtonEvents();

  /**
   * @brief Fills the C structure @arg buttonEvents with one entry specified.
   * @param[out] buttonEvents pointer to fill.
   * @param[in] keyType key type.
   * @param[in] keyValue key type string representation.
   * @param[in] key key.
   * @param[in] value key value.
   * @return true if call was sucessful.
   */
  bool FillRemoteMmiStruct(ButtonEvent** buttonEvents, unsigned short keyType, QString keyValue, unsigned short key, QString value);

  /**
   * @brief Frees the C structure @arg buttonEvents.
   * @param[in] buttonEvents pointer to free (including members).
   */
  void FreeRemoteMmiStruct(ButtonEvent** buttonEvents);

  /**
   * @brief Add focused key to intenal map.
   * @param[in] keyType key type.
   * @param[in] key key.
   * @param[in] message message from user input.
   */
  void AddMmiInFocus(unsigned short keyType, unsigned short key, QString message);

  /**
   * @brief Remove focused key from intenal map.
   * @param[in] keyType key type.
   * @param[in] key key.
   */
  void RemoveMmiInFocus(unsigned short keyType, unsigned short key);

  /**
   * @brief Get focused message.
   * @param[in] keyType key type.
   * @param[in] key key.
   * @param[out] value value of key.
   * @return true if focused key is found.
   */
  bool GetMmiInFocus(unsigned short keyType, unsigned short key, QString& message);
};
#endif /* JABRADEVICE_H */
