#include "SettingListView.h"
#include <QLabel>
#include <QLayout>

SettingListView::~SettingListView() {
  ClearAndDelete();
}

void SettingListView::BuildSettingList(DeviceSettings* settings, QWidget* parent) {

  if(!mInvalidateCache) {
    return;
  }
  /* Build new list of settings: get device settings and add them to the list */
  if(settings) {
    /* Maintain a list of groups so we only display it once */
    QList<QString> groupNames;

    for(unsigned int i = 0; i < settings->settingCount; i++) {
      if(settings->settingInfo && settings->settingInfo[i].groupName) {
        if(!groupNames.contains(settings->settingInfo[i].groupName)) {
          groupNames.push_back(settings->settingInfo[i].groupName);
        }
      }
    }

    /* Sort by group name */
    foreach(QString groupName, groupNames) {
      QLabel* groupNameLabel = new QLabel("<b>" + groupName + "<\b>");
      parent->layout()->addWidget(groupNameLabel);
      mSettingsLabelList.append(groupNameLabel);

      for(unsigned int i = 0; i < settings->settingCount; i++) {
        if(settings->settingInfo && QString(settings->settingInfo[i].groupName) == groupName) {
          if(settings->settingInfo && (settings->settingInfo + i)) {
            SettingWidget* qset = new SettingWidget(settings->settingInfo[i]);
            mSettingsList.append(qset);
            parent->layout()->addWidget(qset);
          }
        }
      }
    }

    for(int i = 0; i < parent->layout()->count(); ++i) {
      QWidget* w = parent->layout()->itemAt(i)->widget();
      if(SettingWidget *qset = qobject_cast<SettingWidget*>(w)) {
        qset->UpdateDependencies();
      }
    }
  }
  mInvalidateCache = false;
}

void SettingListView::ClearAndDelete() {
  if(mSettingsList.count() > 0) {
    qDeleteAll(mSettingsList.begin(), mSettingsList.end());
  }
  if(mSettingsLabelList.count() > 0) {
    qDeleteAll(mSettingsLabelList.begin(), mSettingsLabelList.end());
  }
  mSettingsList.clear();
  mSettingsLabelList.clear();
  mSettingsChanged.clear();
}

void SettingListView::MarkSettingChanged(SettingWidget* setting) {
  if(!mSettingsChanged.contains(setting)) {
    mSettingsChanged.append(setting);
  }
  mInvalidateCache = true;
}

void SettingListView::ClearChanged() {
  mSettingsChanged.clear();
}
