#include "Jdevice.h"
#include <QDebug>
#include <QPainter>
#include <QLabel>
#include <QVBoxLayout>
#include "JabraNativeHid.h"

Jdevice::Jdevice(unsigned short id, unsigned short pid, const QString& name,
                 const QString& usbPath, const QString& instanceId,
                 bool isPairable, const QString& dongleName) :
    mId(id),
    mPid(pid),
    mVersion(0),
    mName(name),
    mUsbPath(usbPath),
    mInstanceId(instanceId),
    mLockedLocally(false),
    mState { false, false, false, false, false, false },
    mIsInitialized(false),
    mDeviceSettings(nullptr),
    mDongleName(dongleName),
    mAutoPairing(false),
    mIsPairable(isPairable),
    mHeadsetConnected(false),
    mIsBatterySupported(false),
    mBusyLightSupported(false),
    mMmiSupported(false) {
}

void Jdevice::Init() {
  /* get product image */
  const char* fileName = Jabra_GetDeviceImagePath(mId);
  if(fileName == nullptr) {
    qCritical() << "Jabra_GetDeviceImagePath returns null";
  }
  else {
    mImage = QPixmap(fileName);
    if(mImage.isNull()) {
      mImage = QPixmap(":/images/UnknownDevice_380x380.png").scaled(380, 380, Qt::KeepAspectRatio);
    }
    Jabra_FreeString(const_cast<char*>(fileName));
  }

  fileName = Jabra_GetDeviceImageThumbnailPath(mId);
  if(fileName == nullptr) {
    qCritical() << "Jabra_GetDeviceImageThumbnailPath returns null";
  }
  else {
    mThumbImage = QPixmap(fileName);
    if(mThumbImage.isNull()) {
      mThumbImage = QPixmap(":/images/UnknownDevice_80x80.png").scaled(80, 80, Qt::KeepAspectRatio);
    }

    Jabra_FreeString(const_cast<char*>(fileName));
  }

  if(mIsPairable) {
    mAutoPairing = Jabra_GetAutoPairing(mId);
  }

  mBusyLightSupported = Jabra_IsBusylightSupported(mId);
  if(mBusyLightSupported) {
    mState.BusyLight = Jabra_GetBusylightStatus(mId);
  }
  mMmiSupported = Jabra_IsRemoteMMISupported(mId);
}

bool Jdevice::InitializeCallControl() {

  bool retval = mIsInitialized;

  if(retval) {
    return retval;
  }

  /* Initialize Device */
  if(Return_Ok != Jabra_SetOffHook(mId, mState.OffHook)) {
    qCritical() << "Jabra_SetOffHook failed during initialization";
    retval = false;
  }
  if(Jabra_IsOnlineSupported(mId)) {
    if(Return_Ok != Jabra_SetRinger(mId, mState.Ringer)) {
      qCritical() << "Jabra_SetRinger failed during initialization";
      retval = false;
    }
  }
  if(Jabra_IsMuteSupported(mId)) {
    if(Return_Ok != Jabra_SetMute(mId, mState.Mute)) {
      qCritical() << "Jabra_SetMute failed during initialization";
      retval = false;
    }
  }
  if(Jabra_IsHoldSupported(mId)) {
    if(Return_Ok != Jabra_SetHold(mId, mState.Hold)) {
      qCritical() << "Jabra_SetHold failed during initialization";
      retval = false;
    }
  }
  if(Jabra_IsOnlineSupported(mId)) {
    if(Return_Ok != Jabra_SetOnline(mId, mState.AudioLink)) {
      qCritical() << "Jabra_SetOnline failed during initialization";
      retval = false;
    }
  }
  int level;
  bool a, b;
  if(Jabra_GetBatteryStatus(mId, &level, &a, &b) == Return_Ok) {
    mIsBatterySupported = true;
  }

  mIsInitialized = true;
  return retval;
}

Jabra_ReturnCode Jdevice::GetBatteryStatus(int *levelInPercent, bool *charging, bool *batteryLow) {
  if(mIsBatterySupported) {
    return Jabra_GetBatteryStatus(mId, levelInPercent, charging, batteryLow);
  }
  return Not_Supported;
}

Jdevice::~Jdevice() {
  if(mDeviceSettings) {
    Jabra_FreeDeviceSettings(mDeviceSettings);
  }
}

/* --------------------------------------------------------*/

DeviceSettings* Jdevice::GetSettings(bool refresh) {
  if(!refresh && mDeviceSettings) {
    return mDeviceSettings;
  }
  if(mDeviceSettings) {
    Jabra_FreeDeviceSettings(mDeviceSettings);
    mDeviceSettings = nullptr;
  }
  mDeviceSettings = Jabra_GetSettings(mId);
  return mDeviceSettings;
}

bool Jdevice::FillSettingStruct(DeviceSettings* deviceSettings, QList<SettingWidget*>& listSettings) {
  int count = listSettings.count();

  deviceSettings->settingCount = count;
  deviceSettings->settingInfo = static_cast<SettingInfo*>(calloc(count, sizeof(SettingInfo)));
  if(deviceSettings->settingInfo == nullptr) {
    qCritical() << "Mem alloc error";
    return false;
  }

  SettingInfo* settingInfo = deviceSettings->settingInfo;

  for(int i=0; i<count; i++, settingInfo++) {
    if(listSettings[i]->Fill(settingInfo) == false) {
      return false;
    }
  }
  return true;
}

void Jdevice::FreeSettingStruct(DeviceSettings* deviceSettings, QList<SettingWidget*>& listSettings) {
  for(unsigned int i=0; i<deviceSettings->settingCount; i++) {
    listSettings[i]->Empty(&(deviceSettings->settingInfo[i]));
  }
  free(deviceSettings->settingInfo);
}

Jabra_ReturnCode Jdevice::SetSettings(QList<SettingWidget*>& listOfChangedSettings) const {
  DeviceSettings deviceSettings = { 0, nullptr, NoError };
  FillSettingStruct(&deviceSettings, listOfChangedSettings);
  Jabra_ReturnCode ret = Jabra_SetSettings(mId, &deviceSettings);
  FreeSettingStruct(&deviceSettings, listOfChangedSettings);
  return ret;
}

/* --------------------------------------------------------*/

bool Jdevice::SetFactoryDefaults() const {
  return Return_Ok == Jabra_FactoryReset(mId, false);
}

bool Jdevice::IsFactoryDefaultSupported() const {
  return Jabra_IsFactoryResetSupported(mId, false);
}

Jabra_ReturnCode Jdevice::Lock() {
  Jabra_ReturnCode ret = Jabra_GetLock(mId);
  mLockedLocally = (ret == Return_Ok);
  return ret;
}

Jabra_ReturnCode Jdevice::Unlock() {
  Jabra_ReturnCode ret = Jabra_ReleaseLock(mId);
  mLockedLocally = (ret != Return_Ok);
  return ret;
}

bool Jdevice::IsLocked() {
  return Jabra_IsLocked(mId);
}

const QPixmap& Jdevice::GetImage() const {
  return mImage;
}

Jabra_ReturnCode Jdevice::StartBtSearch() {
  return Jabra_SetBTPairing(mId);
}

Jabra_ReturnCode Jdevice::SetAutoPairing(bool enable) {
  return Jabra_SetAutoPairing(mId, enable);
}

Jabra_ReturnCode Jdevice::ClearPairingList() {
  return Jabra_ClearPairingList(mId);
}

Jabra_ReturnCode Jdevice::ResetBtAdapter() {
  return Jabra_FactoryReset(mId, true);
}

QString Jdevice::GetConnectedBtDeviceName() {
  char* str = Jabra_GetConnectedBTDeviceName(mId);
  QString retval(str);
  Jabra_FreeString(str);
  return retval;
}

Jabra_ReturnCode Jdevice::ConnectBluetoothDevice() {
  return Jabra_ConnectBTDevice(mId);
}

Jabra_ReturnCode Jdevice::DisconnectBluetoothDevice() {
  return Jabra_DisconnectBTDevice(mId);
}

Jabra_PairingList* Jdevice::GetListOfPairedDevices() {
  return Jabra_GetPairingList(mId);
}

Jabra_PairedDevice* Jdevice::GetPairedDevice(Jabra_PairingList* pairedList, int index) {
  if(pairedList && (index >= 0) && (pairedList->count > 0)) {
    if(index <= (pairedList->count - 1)) {
      if(pairedList->pairedDevice + index) {
        return pairedList->pairedDevice + index;
      }
    }
  }
  return nullptr;
}

QString Jdevice::ToString(const Jabra_PairedDevice* pDevice) {
  QString mac = ToMACString(pDevice->deviceBTAddr);
  mac.append("\t");
  mac.append(pDevice->deviceName);
  return mac;
}

QString Jdevice::ToMACString(char* macAddress) {
  if(macAddress == nullptr) {
    return "null";
  }

  QString str("--:--:--:--:--:--");
  size_t len = strlen(macAddress);
  if(len == 6) {
    unsigned char* p = (unsigned char*)(macAddress);
    str = QString("%1:%2:%3:%4:%5:%6");
    str = str.arg(p[0], 2, 16, QChar('0'));
    str = str.arg(p[1], 2, 16, QChar('0'));
    str = str.arg(p[2], 2, 16, QChar('0'));
    str = str.arg(p[3], 2, 16, QChar('0'));
    str = str.arg(p[4], 2, 16, QChar('0'));
    str = str.arg(p[5], 2, 16, QChar('0'));
  }
  return str;
}

Jabra_ReturnCode Jdevice::GetRemoteMmiButtonFocus(unsigned short typeKey, QString typeValue, unsigned short key, QString value) {
  ButtonEvent* btnEvents = nullptr;
  if(FillRemoteMmiStruct(&btnEvents, typeKey, typeValue, key, value) == false) {
    return System_Error;
  }
  Jabra_ReturnCode ret = Jabra_GetButtonFocus(mId, btnEvents);
  FreeRemoteMmiStruct(&btnEvents);
  return ret;
}

Jabra_ReturnCode Jdevice::ReleaseRemoteMmiButtonFocus(unsigned short typeKey, QString typeValue, unsigned short key, QString value) {
  ButtonEvent* btnEvents = nullptr;
  if(FillRemoteMmiStruct(&btnEvents, typeKey, typeValue, key, value) == false) {
    return System_Error;
  }
  Jabra_ReturnCode ret = Jabra_ReleaseButtonFocus(mId, btnEvents);
  FreeRemoteMmiStruct(&btnEvents);
  return ret;
}

QList<MmiButton> Jdevice::GetSupportedButtonEvents() {
  QList<MmiButton> supported;

  ButtonEvent* mmiSupportedButtonEvents = Jabra_GetSupportedButtonEvents(mId);
  if(mmiSupportedButtonEvents) {
    for(int i=0; i<mmiSupportedButtonEvents->buttonEventCount; ++i) {
      ButtonEventInfo* info = (mmiSupportedButtonEvents->buttonEventInfo + i);
      if(info) {
        MmiButton mmi;
        mmi.name = info->buttonTypeValue;
        mmi.id = info->buttonTypeKey;

        for(int j=0; j<info->buttonEventTypeSize; j++) {
          ButtonEventType* typeInfo = (info->buttonEventType + j);
          if(typeInfo) {
              mmi.events[typeInfo->key].push_back(typeInfo->value);
          }
        }
        supported.push_back(mmi);
      }
    }
    Jabra_FreeButtonEvents(mmiSupportedButtonEvents);
  }
  return supported;
}

bool Jdevice::FillRemoteMmiStruct(ButtonEvent** buttonEvents, unsigned short typeKey, QString typeValue, unsigned short key, QString value) {

  *buttonEvents = static_cast<ButtonEvent*>(calloc(1, sizeof(ButtonEvent)));
  if(*buttonEvents == nullptr) {
    qCritical() << "Mem alloc error";
    return false;
  }
  (*buttonEvents)->buttonEventCount = 1;
  (*buttonEvents)->buttonEventInfo = static_cast<ButtonEventInfo*>(calloc(1, sizeof(ButtonEventInfo)));
  if((*buttonEvents)->buttonEventInfo == nullptr) {
    qCritical() << "Mem alloc error";
    free(*buttonEvents);
    return false;
  }

  int numEvents = 1;
  ButtonEventInfo* eventInfo = (*buttonEvents)->buttonEventInfo;
  eventInfo->buttonTypeKey = typeKey;
  eventInfo->buttonTypeValue = static_cast<char*>(calloc(typeValue.length() + 1, sizeof(char)));
  if(eventInfo->buttonTypeValue == nullptr) {
    qCritical() << "Mem alloc error";
    free((*buttonEvents)->buttonEventInfo);
    free(*buttonEvents);
    return false;
  }
  strncpy(eventInfo->buttonTypeValue, typeValue.toStdString().c_str(), typeValue.length());

  eventInfo->buttonEventTypeSize = numEvents;
  if(numEvents > 0) {
    eventInfo->buttonEventType = static_cast<ButtonEventType*>(calloc(numEvents, sizeof(ButtonEventType)));
    for(int j=0; j<numEvents; j++) {
      ButtonEventType* event = eventInfo->buttonEventType + j;
      size_t len = value.length() + 1;
      event->key = key;
      event->value = static_cast<char*>(calloc(len, sizeof(char)));
      strncpy(event->value, value.toStdString().c_str(), len);
    }
  }
  return true;
}

void Jdevice::FreeRemoteMmiStruct(ButtonEvent** buttonEvents) {
  if(buttonEvents) {
    if(*buttonEvents) {
      for(int i=0; i<(*buttonEvents)->buttonEventCount; i++) {
        ButtonEventInfo *info = (*buttonEvents)->buttonEventInfo + i;
        if(info) {
          if(info->buttonTypeValue) {
            free(info->buttonTypeValue);
          }
          for(int j=0; j<info->buttonEventTypeSize; j++) {
            ButtonEventType* event = info->buttonEventType + j;
            if(event) {
              if(event->value) {
                free(event->value);
              }
              free(event);
            }
          }
          free(info);
        }
      }
    }
    free(*buttonEvents);
  }
}

void Jdevice::AddMmiInFocus(unsigned short keyType, unsigned short key, QString message) {
  QPair<unsigned short, unsigned short> pair({keyType, key});
  mMmiInFocus[pair] = message;
}

void Jdevice::RemoveMmiInFocus(unsigned short keyType, unsigned short key) {
  QPair<unsigned short, unsigned short> pair({keyType, key});
  mMmiInFocus.remove(pair);
}

bool Jdevice::GetMmiInFocus(unsigned short keyType, unsigned short key, QString& message) {
  QPair<unsigned short, unsigned short> pair({keyType, key});
  if(mMmiInFocus.contains(pair)) {
    message = mMmiInFocus.value(pair);
    return true;
  }
  return false;
}

const QString Jdevice::ToString(Jabra_ReturnCode code) {
  switch(code) {
    case Return_Ok:             return QString("Return_Ok");
    case Device_Unknown:        return QString("Device_Unknown");
    case Device_Invalid:        return QString("Device_Invalid");
    case Not_Supported:         return QString("Not_Supported");
    case Return_ParameterFail:  return QString("Return_ParameterFail");
    case No_Information:        return QString("No_Information");
    case NetworkRequest_Fail:   return QString("NetworkRequest_Fail");
    case Device_WriteFail:      return QString("Device_WriteFail");
    case No_FactorySupported:   return QString("No_FactorySupported");
    case Device_Lock:           return QString("Device_Lock");
    case Device_NotLock:        return QString("Device_NotLock");
    case System_Error:          return QString("System_Error");
    case Device_BadState:       return QString("Device_BadState");
    default:                    return QString(QObject::tr("Unknown return code"));
  }
}
