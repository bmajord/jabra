#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMutex>
#include <QMessageBox>
#include <QCloseEvent>

#include "JabraDeviceConfig.h"
#include "Common.h"
#include "ThumbListView.h"
#include "Jdevice.h"
#include "RemoteMmiListView.h"
#include "SettingListView.h"
#include "SettingWidget.h"

namespace Ui {
  class MainWindow;
}

/**
 * @brief The MainWindow class.
 */
class MainWindow : public QMainWindow
{
  Q_OBJECT

private:
  /**
   * @brief Constructor, made private as this class is a singleton.
   * @param[in] parnt parent widget owner.
   */
  explicit MainWindow(QWidget *parnt = 0);

  /** Copy constructor, made private to prevent copying. */
  MainWindow(MainWindow const&);

  /** Assignment operator, made private to prevent assignment. */
  void operator=(MainWindow const&);

  /** Preview area, used to display attached devices. */
  ThumbListView* mPreviewArea;

  /** Main window. */
  Ui::MainWindow *ui;

  /** Area for displaying list of setting widgets. */
  SettingListView mSettingListArea;

  /** Area for displaying remote MMI (if supported) */
  RemoteMmiListView* mRemoteMmiList;

  /** Mutex for API protection. */
  QMutex mMtx;

  /** Map of remote MMI in focus. */
  QMap<unsigned short, QList<MmiButton>> mMmiInFocus;

  /**
   * @brief Reads the application ID from a file. The application ID must
   * be an ASCII string located in the first line of the file. Whitespaces
   * in the start and end of the line  are removed. The application ID must
   * be set using Jabra_SetAppID before the library initialization routine
   * Jabra_Initialize is called.
   * @param[in] filename name of file containing the application ID.
   * @return a string containing the first line of the file.
   */
  const QString ReadAppIdFile(const QString& filename);

public:
  ~MainWindow();

  /**
   * @brief Close event, called when user is trying to close window. The close event
   * might be ignored (by the user) if unapplied settings are present.
   * @param[in] ev close event.
   */
  void closeEvent(QCloseEvent *ev);

  /**
   * @brief Get instance of class (singleton).
   * @return instance of class.
   */
  static MainWindow& GetInstance() {
    static MainWindow sInstance;
    return sInstance;
  }

private:

  /** Static callback called when first scan is done */
  static void JabraFirstScanForDeviceDoneFunc();

  /**
   * @brief Static callback called when a Jabra device is attached.
   * @param[in] deviceInfo structure containing misc. information about the device attached.
   */
  static void JabraDeviceAttachedFunc(Jabra_DeviceInfo deviceInfo);

  /**
   * @brief Static callback called when a Jabra device is removed.
   * @param[in] deviceID API device ID used for API calls, used to distinguish the Jabra devices from each other.
   */
  static void JabraDeviceRemovedFunc(unsigned short deviceID);

  /**
   * @brief Static callback called when raw HID button data is sent by the Jabra device.
   * @param[in] deviceID API device ID used for API calls, used to distinguish the Jabra devices from each other.
   * @param[in] usagePage the HID usage page that caused the callback to be called.
   * @param[in] usage the HID usage id that caused the callback to be called.
   * @param[in] buttonInData the value of the usage.
   */
  static void JabraButtonInDataRawHidFunc(unsigned short deviceID, unsigned short usagePage, unsigned short usage, bool buttonInData);

  /**
   * Static callback called when button data is sent by the Jabra device.
   * @brief JabraButtonInDataTranslatedFunc
   * @param[in] deviceID API device ID used for API calls, used to distinguish the Jabra devices from each other.
   * @param[in] translatedInData the HID input that caused the callback to be called.
   * @param[in] buttonInData the value of the HID input.
   */
  static void JabraButtonInDataTranslatedFunc(unsigned short deviceID, Jabra_HidInput translatedInData, bool buttonInData);

  /**
   * @brief Static callback called when busylight is toggled.
   * @param[in] deviceID API device ID used for API calls, used to distinguish the Jabra devices from each other.
   * @param[in] busylightValue value (current state) of the busylight. True means on, false off.
   */
  static void JabraBusylightFunc(unsigned short deviceID, bool busylightValue);

  /**
   * @brief Static callback called when GN button event is sent by the Jabra device.
   * @param[in] deviceID API device ID used for API calls, used to distinguish the Jabra devices from each other.
   * @param[in] buttonEvent
   */
  static void JabraButtonGNPEventFunc(unsigned short deviceID, ButtonEvent* buttonEvent);

  /**
   * Static callback called when a device is paired and added to the paried device list.
   * @brief JabraPairingListFunc
   * @param[in] deviceID API device ID used for API calls, used to distinguish the Jabra devices from each other.
   * @param[in] lst
   */
  static void JabraPairingListFunc(unsigned short deviceID, Jabra_PairingList* lst);

  /** Update UI components */
  void UpdateUiComponents();

  /** Update UI components: device info */
  void UpdateUiComponentsProductInfo(Jdevice* device);

  /** Update UI components: settings related */
  void UpdateUiComponentsSettings(Jdevice* device);

  /** Update UI components: call control related */
  void UpdateUiComponentsCallControl(Jdevice* device);

  /** Update UI components: Bluetooth related */
  void UpdateUiComponentsBluetooth(Jdevice* device);

  /** Update UI components: MMI related */
  void UpdateUiComponentsMmi(Jdevice* device);

  /** Helper for showing message box to the user */
  enum QMessageBox::StandardButton showMessage(const QString& info, const QString& text, QFlags<QMessageBox::StandardButton> = QMessageBox::Ok);

private slots:
  /** Slots */
  void OnJabraDeviceAdded(Jdevice* device);
  void OnJabraDeviceRemoved(unsigned short deviceID);
  void OnJabraButtonInDataRawHidFunc(unsigned short deviceID, unsigned short usagePage, unsigned short usage, bool buttonInData);
  void OnJabraButtonInDataTranslatedFunc(unsigned short deviceID, Jabra_HidInput translatedInData, bool buttonInData);
  void OnJabraBusylightFunc(unsigned short deviceID, bool busylightValue);
  void OnJabraButtonGNPEventFunc(unsigned short deviceID, ButtonEvent* buttonEvent);
  void OnJabraPairingListFunc(unsigned short deviceID, Jabra_PairingList* lst);

  /** Settings related slots */
  void on_pushBtnStApply_clicked();
  void on_pushBtnStFactoryDefaults_clicked();

  /** CallControl related slots */
  void on_pushBtnCcOffHook_clicked();
  void on_pushBtnCcMute_clicked();
  void on_pushBtnCcRinger_clicked();
  void on_pushBtnCcHold_clicked();
  void on_pushBtnCcAudioLink_clicked();
  void on_pushBtnCcBusyLight_clicked();
  void on_pushBtnCcClear_clicked();
  void on_pushBtnCcRefresh_clicked();

  /** Bluetooth related slots */
  void on_pushBtnBtStart_clicked();
  void on_checkBoxBtAutoSearch_clicked(bool checked);
  void on_pushBtnBtConnect_clicked();
  void on_pushBtnBtClearAll_clicked();
  void on_pushBtnBtReset_clicked();
  void on_pushBtnBtClear_clicked();
  void on_pushBtnBtConnect2_clicked();

  /** Remote MMI related slots */
  void on_pushBtnMmiClear_clicked();
  void onRemoteMmiFocusGet(unsigned short keyType, QString keyValue, unsigned short key, QString value, QString message);
  void onRemoteMmiFocusRelease(unsigned short keyType, QString keyValue, unsigned short key, QString value);

  /** Common related slots */
  void on_tab_currentChanged(int index);

public slots:
  void onDeviceSelected(Jdevice*);
  void onDeviceLocked(Jdevice*);
  void onSettingChanged(SettingWidget*);

signals:
  void signalOnJabraDeviceAdded(Jdevice*);
  void signalOnJabraDeviceRemoved(unsigned short);
  void signalOnJabraButtonInDataRawHidFunc(unsigned short, unsigned short, unsigned short, bool);
  void signalOnJabraButtonInDataTranslatedFunc(unsigned short, Jabra_HidInput, bool);
  void signalOnJabraBusylightFunc(unsigned short deviceID, bool busylightValue);
  void signalOnJabraButtonGNPEventFunc(unsigned short deviceID, ButtonEvent *buttonEvent);
  void signalOnJabraPairingListFunc(unsigned short deviceID, Jabra_PairingList *lst);
};

#endif /* MAINWINDOW_H */
