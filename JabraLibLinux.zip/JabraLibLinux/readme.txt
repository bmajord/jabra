Jabra SDK V2 - Linux Release
Version : 1.0.11.1_2
Date    : 2017.06.27

================================================================================
Jabra SDKV2 provides application interfaces to:
- List and connect Jabra devices
- Read and change settings in Jabra devices
- Perform remote call control
- Configure and subscribe to Button events
- Dongle support (Link360 and Link370)

================================================================================
SYSTEM REQUIREMENTS:
- OS support: Linux Ubuntu 17.04 LTS (32-bit and 64 bit)
- Network availability

================================================================================
DEMO APP INSTALLATION:
- Unzip the SDK archive to a folder and launch the demo app present in the
  demo folder

================================================================================
GETTING STARTED:
- To create new applications refer to the user guide and sample source code

================================================================================
For more information and licence agreement please visit
https://developer.jabra.com/
